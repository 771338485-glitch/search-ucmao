import concurrent.futures
import json
import logging
import random
import re
import time
import threading

import jmespath
import requests

from configs.app_config import user_agents, SEARCH_MAX_CONCURRENCY, SEARCH_VARIANT_TRIGGER, SEARCH_PLUGIN_TIMEOUT_MS
from src.db.resources_dao import search_resources_by_keyword, search_resources_advanced
from utils.netdisk_utils import match_netdisk_link
from src.pan_operator import create_share

logger = logging.getLogger(__name__)

# API 配置缓存
_api_config_cache = None
_api_config_cache_time = 0
_api_config_cache_lock = threading.Lock()
_API_CONFIG_CACHE_TTL = 60  # 缓存 60 秒


def read_all_api_configs_from_db():
    """从数据库读取所有 API 配置（用于搜索服务，不排序）"""
    from src.db.api_config_dao import get_all_configs
    return get_all_configs(order_by_created=False)


def get_cached_api_configs():
    """获取缓存的 API 配置"""
    global _api_config_cache, _api_config_cache_time
    
    current_time = time.time()
    
    with _api_config_cache_lock:
        # 检查缓存是否过期
        if _api_config_cache is None or (current_time - _api_config_cache_time) > _API_CONFIG_CACHE_TTL:
            logger.debug("刷新 API 配置缓存")
            _api_config_cache = read_all_api_configs_from_db()
            _api_config_cache_time = current_time
        
        return _api_config_cache


read_api_configs = read_all_api_configs_from_db


# API 响应时间记录
api_response_times = {}
api_response_times_lock = threading.Lock()

def fetch_data(url, method, request_data, timeout=5):
    """根据配置发起 HTTP 请求并返回响应内容。"""
    headers = {
        "User-Agent": random.choice(user_agents),
        "Content-Type": "application/json",
    }

    try:
        data_obj = json.loads(request_data) if request_data else None
    except json.JSONDecodeError:
        data_obj = {}

    response = None
    start_time = time.time()

    try:
        if method.upper() == "GET":
            response = requests.get(url, headers=headers, params=data_obj, timeout=timeout)
        elif method.upper() == "POST":
            response = requests.post(url, headers=headers, json=data_obj, timeout=timeout)
        else:
            raise requests.exceptions.RequestException(f"不支持的 HTTP 方法: {method}")

        response.raise_for_status()
        json_data = response.json()
        
        # 记录响应时间
        response_time = time.time() - start_time
        with api_response_times_lock:
            api_response_times[url] = response_time
        logger.debug(f"API 请求成功 ({url}) - 响应时间: {response_time:.2f}秒")
        
        return json_data

    except requests.exceptions.Timeout:
        logger.warning(f"API 请求超时 ({url}) - 超时时间: {timeout}秒")
        return None
    except requests.exceptions.RequestException as e:
        logger.error(f"API 请求失败 ({url}): {e}")
        return None
    except json.JSONDecodeError:
        logger.error(f"API 响应不是有效的 JSON ({url})")
        return None


def extract_from_json(json_data, jmespath_query):
    """使用 JMESPath 表达式从 JSON 数据中提取结果。"""
    if not json_data or not jmespath_query:
        return []

    try:
        results = jmespath.search(jmespath_query, json_data)

        if not results:
            logger.debug("JMESPath 查询未找到结果")
            return []
            
        if not isinstance(results, list):
            logger.debug("JMESPath 查询结果不是列表")
            return []
            
        # 支持两种格式：
        # 1. [ [title, url], ... ] - 旧格式
        # 2. [ [title, url, datetime], ... ] - 新格式（带日期）
        formatted_results = []
        for item in results:
                if not isinstance(item, (list, tuple)):
                    logger.debug(f"搜索结果项不是列表或元组: {item}")
                    continue
                    
                if len(item) >= 3:
                    # 新格式：带日期
                    try:
                        formatted_results.append([str(item[0]), str(item[1]), str(item[2])])
                    except (IndexError, TypeError, ValueError) as e:
                        logger.debug(f"格式化搜索结果失败: {e}")
                        continue
                elif len(item) >= 2:
                    # 旧格式：不带日期
                    try:
                        formatted_results.append([str(item[0]), str(item[1]), ""])
                    except (IndexError, TypeError, ValueError) as e:
                        logger.debug(f"格式化搜索结果失败: {e}")
                        continue
                else:
                    logger.debug(f"搜索结果项长度不足: {item}")
                    continue
        return formatted_results

    except Exception as e:
        logger.error(f"JMESPath 提取失败 (Query: {jmespath_query}): {e}")
        return []

    return []


def replace_keyword_in_config(configs, placeholder, keyword):
    """用实际关键词替换 API 配置中的占位符（如 '[[keyword]]'）。"""
    updated_configs = []
    placeholder = str(placeholder)
    keyword = str(keyword)

    for config in configs:
        new_config = config.copy()

        # 替换 URL
        if "url" in new_config and isinstance(new_config["url"], str):
            new_config["url"] = new_config["url"].replace(placeholder, keyword)

        # 替换 Request Body (JSON 字符串)
        if "request" in new_config and isinstance(new_config["request"], str):
            new_config["request"] = new_config["request"].replace(placeholder, keyword)

        updated_configs.append(new_config)
    return updated_configs


def filter_output(extracted_data, keyword):
    """根据关键词过滤结果，实现模糊匹配。"""
    separator_pattern = r"[,、|;+\-/	\n*#\s]"
    processed_keyword = re.sub(separator_pattern, " ", keyword)

    keyword_list = [kw.strip() for kw in processed_keyword.split() if kw.strip()]

    filtered_list = []

    for item in extracted_data:
        title = item[0]

        for kw in keyword_list:
            if kw in title:
                filtered_list.append(item)
                break

    return filtered_list


def clean_and_extract_data(data):
    """
    清洗并提取数据，并新增网盘信息。
    输入格式: [[source, title, url], ...] 或 [[source, title, url, datetime], ...]
    输出格式: [[source, title, url, netdisk_name, datetime, is_valid], ...]
    注意: 这里先默认所有链接都是有效的，后续会通过异步任务检查并更新
    """

    def extract_url(url):
        """ 清洗URL冗余内容后，提取http/磁力/迅雷等常见链接，无匹配则返回清洗后原文 """
        url = str(url).strip()
        url = re.sub(r"</?br\s*/?>.*分享", "", url, flags=re.IGNORECASE)
        url = re.sub(r"</?br\s*/?>", " ", url, flags=re.IGNORECASE)
        url_pattern = re.compile(r"(magnet:|thunder://|ed2k://|https?:\/\/).*?(?=\s|$)", re.IGNORECASE)
        match = url_pattern.search(url)
        if match:
            return match.group(0)
        return url

    def extract_title(title):
        """ 移除标题中的所有 HTML 标签（通用版），并轻量格式化 """
        title = str(title)
        title = re.sub(r"</?\w+[^>]*>", "", title)
        title = re.sub(r"(\[?(描述|简介|介绍)\]?)\s*[：:]\s*.*?$", "", title)
        title = re.sub(r"\s+", " ", title)
        return title.strip()

    def format_datetime(dt_str):
        """格式化日期时间字符串"""
        if not dt_str:
            return ""
        try:
            from datetime import datetime
            dt_str = str(dt_str).strip()
            # 过滤无效日期
            if dt_str == '0001-01-01T00:00:00Z' or dt_str == '0001-01-01':
                return ""
            if 'T' in dt_str:
                dt = datetime.fromisoformat(dt_str.replace('Z', '+00:00'))
                # 过滤年份小于 2000 的日期
                if dt.year < 2000:
                    return ""
                return dt.strftime('%Y-%m-%d %H:%M')
            # 处理纯日期格式，检查年份
            if len(dt_str) >= 10:
                date_part = dt_str[:10]
                # 尝试解析日期
                try:
                    dt = datetime.strptime(date_part, '%Y-%m-%d')
                    if dt.year < 2000:
                        return ""
                    return date_part
                except:
                    return date_part
            return dt_str
        except:
            return dt_str

    cleaned_data = []
    for d_lst in data:
        source = d_lst[0]
        title = extract_title(d_lst[1])
        url = extract_url(d_lst[2])
        
        # 过滤掉空链接
        if not url or url.strip() == '':
            continue
        
        netdisk_name = match_netdisk_link(url)
        datetime_str = format_datetime(d_lst[3]) if len(d_lst) > 3 else ""
        
        # 不设置默认值，保持 undefined 状态，前端会显示"检查中"
        cleaned_data.append([source, title, url, netdisk_name, datetime_str, None])
    
    # 启动异步任务检查所有链接的有效性
    import concurrent.futures
    def check_validity_async(results):
        from utils.netdisk_utils import check_link_validity
        
        def check_single_result(result):
            try:
                url = result[2]
                is_valid = check_link_validity(url)
                result[5] = is_valid
            except Exception as e:
                logger.error(f"异步检查链接有效性失败: {e}")
                result[5] = True  # 出错时默认为有效
        
        # 使用线程池批量检查，最多 15 个并发
        with concurrent.futures.ThreadPoolExecutor(max_workers=15) as executor:
            executor.map(check_single_result, results)

    # 启动线程进行异步检查
    import threading
    thread = threading.Thread(target=check_validity_async, args=(cleaned_data,))
    thread.daemon = True
    thread.start()

    return cleaned_data


def process_config(config, keyword):
    """
    处理单个 API 配置，获取、筛选数据，并返回包含网盘名称的结果。
    """
    config_name = config.get("name", "未知 API")
    final_results = []

    try:
        logger.debug(f"开始调用 API: '{config_name}' ({config['url']})")
        response_data = fetch_data(config["url"], config["method"], config["request"])

        if not response_data:
            logger.debug(f"API '{config_name}' 没有返回数据")
            return []

        extracted_data = extract_from_json(response_data, config["response"])
        
        if not extracted_data or not isinstance(extracted_data, list):
            logger.debug(f"API '{config_name}' 提取的数据为空或格式不正确")
            return []

        filtered_data = filter_output(extracted_data, keyword)
        
        if not filtered_data:
            logger.debug(f"API '{config_name}' 过滤后没有匹配的结果")
            return []

        filtered_data_with_keyword = [["other", item[0], item[1], item[2]] for item in filtered_data]
        final_results = clean_and_extract_data(filtered_data_with_keyword)

        num_results = len(final_results)
        logger.debug(f"API '{config_name}' 搜索到 {num_results} 条资源")

    except Exception as e:
        logger.error(f"处理配置 '{config_name}' ({config['url']}) 时发生异常: {e}")
        return []

    return final_results


def generate_search_keyword_variants(keyword: str) -> list:
    """
    生成关键词变体，用于提升搜索命中率
    参考 PanHub 的实现
    """
    keyword = keyword.strip()
    if not keyword:
        return []
    
    variants = [keyword]
    
    # 如果关键词长度 <= 1，添加一些通用变体
    if len(keyword) <= 1:
        variants.extend([keyword, "电影", "movie", "1080p"])
        return variants
    
    # 尝试分词（按常见分隔符）
    separators = r'[,、|;+\-/\s\n\t]'
    parts = re.split(separators, keyword)
    parts = [p.strip() for p in parts if p.strip()]
    
    # 如果有多个部分，生成部分关键词
    if len(parts) > 1:
        # 添加前2个词
        if len(parts) >= 2:
            variants.append(' '.join(parts[:2]))
        # 添加第一个词
        if parts:
            variants.append(parts[0])
    else:
        # 对于单一部分的关键词（特别是中文），尝试生成更短的变体
        # 使用正则表达式移除常见后缀
        base_keyword = keyword
        
        # 移除第X季（支持阿拉伯数字和中文数字）
        # 中文数字：一、二、三、四、五、六、七、八、九、十、十一、十二...
        season_pattern = r'第(\d+|[一二三四五六七八九十百千]+)季$'
        if re.search(season_pattern, keyword):
            base_keyword = re.sub(season_pattern, '', keyword)
            if base_keyword:
                variants.append(base_keyword)
        else:
            # 移除其他常见后缀
            other_suffixes = ['剧场版', '真人版', '动画版', '电影版', '全集', '完整版', '高清', '超清', '蓝光']
            for suffix in other_suffixes:
                if keyword.endswith(suffix):
                    base_keyword = keyword[:-len(suffix)]
                    if base_keyword:
                        variants.append(base_keyword)
                    break
        
        # 如果还没生成其他变体，尝试截断关键词
        if len(variants) == 1:
            # 对于较长的关键词，尝试截断成不同长度
            if len(keyword) >= 6:
                variants.append(keyword[:4])  # 前4个字
            if len(keyword) >= 4:
                variants.append(keyword[:2])  # 前2个字
    
    # 去重
    seen = set()
    unique_variants = []
    for v in variants:
        if v and v not in seen:
            seen.add(v)
            unique_variants.append(v)
    
    # 最多返回3个变体
    return unique_variants[:3]


def search_in_database(keyword):
    """
    从内部数据库搜索，并新增网盘信息。
    返回格式: [[source, title, url, netdisk_name, datetime, is_valid], ...]
    注意: 这里先默认所有链接都是有效的，后续会通过异步任务检查并更新
    """
    try:
        # 使用 DAO 搜索资源
        results = search_resources_by_keyword(keyword)

        final_results = []
        for name, link, cloud_name in results:
            netdisk_name = cloud_name if cloud_name else match_netdisk_link(link)
            # 不设置默认值，保持 None 状态，前端会显示"检查中"
            # 添加空的日期时间字段和有效性字段，保持与 API 结果格式一致
            final_results.append(["hot", name, link, netdisk_name, "", None])

        num_results = len(final_results)
        logger.debug(f"内部数据库搜索到 {num_results} 条资源")
        
        # 启动异步任务检查所有链接的有效性
        import concurrent.futures
        def check_validity_async(results):
            from utils.netdisk_utils import check_link_validity
            
            def check_single_result(result):
                try:
                    url = result[2]
                    is_valid = check_link_validity(url)
                    result[5] = is_valid
                except Exception as e:
                    logger.error(f"异步检查链接有效性失败: {e}")
                    result[5] = True  # 出错时默认为有效
            
            # 使用线程池批量检查，最多 15 个并发
            with concurrent.futures.ThreadPoolExecutor(max_workers=15) as executor:
                executor.map(check_single_result, results)

        # 启动线程进行异步检查
        import threading
        thread = threading.Thread(target=check_validity_async, args=(final_results,))
        thread.daemon = True
        thread.start()

        return final_results

    except Exception as err:
        logger.error(f"数据库错误: {err}")
        return []


def generate_search_stream_events(keyword):
    """
    生成搜索结果的 SSE 事件流 (生成字符串, 不直接返回 Response
    参考 PanHub 的实现：
    1. 先使用原始关键词搜索
    2. 如果结果太少，尝试关键词变体
    3. 限制并发数
    """

    def _event_generator():
        db_results = search_in_database(keyword)
        total_results_count = len(db_results) if db_results else 0
        
        if db_results:
            yield json.dumps({"type": "initial", "results": db_results})

        urls_config = get_cached_api_configs()
        enabled_configs = [c for c in urls_config if c.get("status", False) and c.get("is_enabled", False)]

        # 根据API响应时间排序，优先调用响应快的API
        def get_api_response_time(config):
            url = config.get("url", "")
            with api_response_times_lock:
                return api_response_times.get(url, 9999)
        
        enabled_configs.sort(key=get_api_response_time)

        enabled_urls = [c["url"] for c in enabled_configs]
        logger.debug(f"本次搜索启用的 API 数量: {len(enabled_urls)} 个")
        logger.debug(f"API 响应时间排序: {[(c['url'], get_api_response_time(c)) for c in enabled_configs]}")

        # 生成关键词变体
        keyword_variants = generate_search_keyword_variants(keyword)
        logger.info(f"关键词 '{keyword}' 的变体列表: {keyword_variants}")
        logger.info(f"变体搜索触发阈值: {SEARCH_VARIANT_TRIGGER} 条结果")

        # 先尝试原始关键词
        current_variant_index = 0
        processed_keywords = set()

        while current_variant_index < len(keyword_variants):
            current_keyword = keyword_variants[current_variant_index]
            
            # 避免重复搜索相同关键词
            if current_keyword in processed_keywords:
                current_variant_index += 1
                continue
            processed_keywords.add(current_keyword)

            logger.info(f"===== 开始使用关键词 '{current_keyword}' 搜索 (变体 {current_variant_index + 1}/{len(keyword_variants)}) =====")

            urls_config_search = replace_keyword_in_config(enabled_configs, "[[keyword]]", current_keyword)

            # 使用配置的并发数
            logger.info(f"使用 {SEARCH_MAX_CONCURRENCY} 个并发请求 API")
            with concurrent.futures.ThreadPoolExecutor(max_workers=SEARCH_MAX_CONCURRENCY) as executor:
                futures = [executor.submit(process_config, config, current_keyword) for config in urls_config_search]
                pending_futures = set(futures)

                while pending_futures:
                    done, pending_futures = concurrent.futures.wait(
                        pending_futures, timeout=None, return_when=concurrent.futures.FIRST_COMPLETED
                    )

                    for future in done:
                        try:
                            results = future.result()
                            if results:
                                total_results_count += len(results)
                                yield json.dumps({"type": "update", "results": results})
                        except Exception as e:
                            logger.error(f"SSE 收集结果时发生异常: {e}")

                    time.sleep(0.01)

            # 检查是否需要尝试下一个变体
            if total_results_count >= SEARCH_VARIANT_TRIGGER:
                logger.info(f"✅ 已找到 {total_results_count} 条结果，达到阈值 {SEARCH_VARIANT_TRIGGER}，停止变体搜索")
                break

            current_variant_index += 1
            if current_variant_index < len(keyword_variants):
                logger.info(f"⚠️ 结果数量不足 ({total_results_count}/{SEARCH_VARIANT_TRIGGER})，尝试下一个关键词变体")

        logger.info(f"🎉 关键词 '{keyword}' 所有搜索完成，共找到 {total_results_count} 条结果")
        yield json.dumps({"type": "end"})

    return _event_generator()


def search_resources(name="", cloud_name="", resource_type="", limit=100, sort="default"):
    """
    通过名称、云名称或类型搜索资源
    返回: (success: bool, message: str, results: list)
    """
    try:
        return search_resources_advanced(name=name, cloud_name=cloud_name, resource_type=resource_type, limit=limit, sort=sort)
    except Exception as e:
        logger.error(f"API错误: {e}")
        return False, f"API错误: {e}", []


