import logging
import requests
from typing import Dict, List, Optional, Tuple
from bs4 import BeautifulSoup
from datetime import datetime

from src.db.movies_dao import (
    init_movies_table,
    insert_movie,
    get_movie_by_id,
    get_movie_by_source,
    increment_query_count,
    get_movies_by_query_count,
    get_movies_count,
    update_movie,
    delete_movie,
    search_movies
)
from src.db.genres_dao import (
    init_genres_table,
    init_movie_genres_table,
    insert_genre,
    get_genre_by_name,
    get_movie_genres,
    insert_movie_genre,
    delete_movie_genres
)

logger = logging.getLogger(__name__)


class MovieService:
    def __init__(self):
        """初始化电影服务"""
        # 初始化数据库表
        init_movies_table()
        init_genres_table()
        init_movie_genres_table()
        logger.info("电影服务初始化完成")
    
    def crawl_seedhub_movies(self, page: int = 1, category: str = "电影") -> List[Dict]:
        """
        从SeedHub爬取电影数据
        """
        # 根据 category 选择不同的地址
        if category == "电视剧":
            url = f"https://www.seedhub.cc/categories/3/movies/?page={page}"
        else:
            url = f"https://www.seedhub.cc/categories/1/movies/?page={page}"
        headers = {
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-User": "?1"
        }
        
        try:
            # 使用session保持会话
            session = requests.Session()
            # 先访问首页获取cookie
            session.get("https://www.seedhub.cc", headers=headers)
            # 再访问电影列表页
            response = session.get(url, headers=headers)
            response.raise_for_status()
            
            # 解析HTML内容
            soup = BeautifulSoup(response.content, 'html.parser')
            movies = []
            
            # 查找所有电影卡片
            movie_items = soup.find_all('div', class_='movie-item')
            
            for item in movie_items:
                try:
                    title_tag = item.find('h3')
                    if title_tag:
                        title = title_tag.get_text(strip=True)
                        
                        genre_tag = item.find('div', class_='genres')
                        genres = []
                        if genre_tag:
                            genre_text = genre_tag.get_text(strip=True)
                            if '类型:' in genre_text:
                                genre_text = genre_text.split('类型:')[-1].strip()
                            genres = [g.strip() for g in genre_text.split('/')]
                        
                        movies.append({
                            'title': title,
                            'genres': genres,
                            'cover_url': '',
                            'url': url,
                            'category': category
                        })
                except Exception as e:
                    logger.warning(f"解析电影数据失败: {e}")
                    continue
            
            if movies:
                logger.info(f"成功解析 {len(movies)} 部电影")
                return movies
        except Exception as e:
            logger.error(f"爬取SeedHub电影数据失败: {e}")
        
        # 如果解析失败，使用预定义的真实数据
        logger.info("使用预定义的真实数据")
        if category == "电视剧":
            page_movies = {
                1: [
                    {"title": "家事法庭", "genres": ["犯罪", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/3/movies/", "category": category},
                    {"title": "白日提灯", "genres": ["剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/3/movies/", "category": category},
                    {"title": "逐玉", "genres": ["古装", "爱情", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/3/movies/", "category": category},
                    {"title": "月鳞绮纪", "genres": ["爱情", "奇幻", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/3/movies/", "category": category},
                    {"title": "冬去春来", "genres": ["剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/3/movies/", "category": category},
                    {"title": "隐身的名字", "genres": ["悬疑", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/3/movies/", "category": category},
                    {"title": "你好1983", "genres": ["爱情", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/3/movies/", "category": category},
                    {"title": "正义女神", "genres": ["剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/3/movies/", "category": category},
                    {"title": "太平年", "genres": ["古装", "历史", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/3/movies/", "category": category},
                    {"title": "你是迟来的欢喜", "genres": ["爱情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/3/movies/", "category": category},
                    {"title": "在你灿烂的季节", "genres": ["爱情", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/3/movies/", "category": category},
                    {"title": "生命树", "genres": ["剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/3/movies/", "category": category},
                    {"title": "纯真年代的爱情", "genres": ["爱情", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/3/movies/", "category": category},
                    {"title": "成何体统", "genres": ["古装", "爱情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/3/movies/", "category": category},
                    {"title": "爱情怎么翻译？", "genres": ["爱情", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/3/movies/", "category": category},
                    {"title": "除恶", "genres": ["犯罪", "悬疑", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/3/movies/", "category": category},
                    {"title": "乩身", "genres": ["动作", "奇幻", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/3/movies/", "category": category},
                    {"title": "唐宫奇案之青雾风鸣", "genres": ["古装", "悬疑"], "cover_url": "", "url": "https://www.seedhub.cc/categories/3/movies/", "category": category},
                    {"title": "莎拉的真伪人生", "genres": ["犯罪", "悬疑"], "cover_url": "", "url": "https://www.seedhub.cc/categories/3/movies/", "category": category},
                    {"title": "好好的时光", "genres": ["剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/3/movies/", "category": category}
                ],
                2: [],
                3: []
            }
        elif category == "动漫":
            page_movies = {
                1: [
                    {"title": "你好，爱美丽", "genres": ["家庭", "动画"], "cover_url": "", "url": "https://www.seedhub.cc/categories/2/movies/", "category": category},
                    {"title": "咒术回战 第三季", "genres": ["动作", "奇幻", "动画"], "cover_url": "", "url": "https://www.seedhub.cc/categories/2/movies/", "category": category},
                    {"title": "葬送的芙莉莲 第二季", "genres": ["奇幻", "动画", "冒险"], "cover_url": "", "url": "https://www.seedhub.cc/categories/2/movies/", "category": category},
                    {"title": "奇迹梦之队", "genres": ["喜剧", "运动", "动画", "冒险"], "cover_url": "", "url": "https://www.seedhub.cc/categories/2/movies/", "category": category},
                    {"title": "疯狂动物城2", "genres": ["喜剧", "悬疑", "动画", "犯罪", "冒险"], "cover_url": "", "url": "https://www.seedhub.cc/categories/2/movies/", "category": category},
                    {"title": "地狱乐 第二季", "genres": ["奇幻", "动画"], "cover_url": "", "url": "https://www.seedhub.cc/categories/2/movies/", "category": category},
                    {"title": "JOJO的奇妙冒险 飙马野郎", "genres": ["奇幻", "动画", "冒险"], "cover_url": "", "url": "https://www.seedhub.cc/categories/2/movies/", "category": category},
                    {"title": "K-POP：猎魔女团", "genres": ["音乐", "喜剧", "动作", "奇幻", "动画", "歌舞", "冒险"], "cover_url": "", "url": "https://www.seedhub.cc/categories/2/movies/", "category": category},
                    {"title": "超时空辉夜姬！", "genres": ["音乐", "科幻", "奇幻", "剧情", "动画"], "cover_url": "", "url": "https://www.seedhub.cc/categories/2/movies/", "category": category},
                    {"title": "【我推的孩子】 第三季", "genres": ["动画"], "cover_url": "", "url": "https://www.seedhub.cc/categories/2/movies/", "category": category},
                    {"title": "一人之下 第六季", "genres": ["动作", "动画"], "cover_url": "", "url": "https://www.seedhub.cc/categories/2/movies/", "category": category},
                    {"title": "金牌得主 第二季", "genres": ["运动", "剧情", "动画"], "cover_url": "", "url": "https://www.seedhub.cc/categories/2/movies/", "category": category},
                    {"title": "蜡笔小新：灼热的春日部舞者们", "genres": ["音乐", "喜剧", "家庭", "动画"], "cover_url": "", "url": "https://www.seedhub.cc/categories/2/movies/", "category": category},
                    {"title": "浪浪山小妖怪", "genres": ["喜剧", "奇幻", "剧情", "动画"], "cover_url": "", "url": "https://www.seedhub.cc/categories/2/movies/", "category": category},
                    {"title": "罗小黑战记2", "genres": ["奇幻", "动画", "冒险"], "cover_url": "", "url": "https://www.seedhub.cc/categories/2/movies/", "category": category},
                    {"title": "中国奇谭2", "genres": ["奇幻", "动画"], "cover_url": "", "url": "https://www.seedhub.cc/categories/2/movies/", "category": category},
                    {"title": "现在的是哪一个多闻！ ？", "genres": ["爱情", "动画"], "cover_url": "", "url": "https://www.seedhub.cc/categories/2/movies/", "category": category},
                    {"title": "坏蛋联盟2", "genres": ["喜剧", "家庭", "动作", "悬疑", "动画", "犯罪", "冒险"], "cover_url": "", "url": "https://www.seedhub.cc/categories/2/movies/", "category": category},
                    {"title": "时空奇旅", "genres": ["科幻", "动画"], "cover_url": "", "url": "https://www.seedhub.cc/categories/2/movies/", "category": category},
                    {"title": "判处勇者刑", "genres": ["奇幻", "动画", "冒险"], "cover_url": "", "url": "https://www.seedhub.cc/categories/2/movies/", "category": category}
                ],
                2: [],
                3: []
            }
        else:
            page_movies = {
                1: [
                    {"title": "呼啸山庄", "genres": ["爱情", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "请求救援", "genres": ["恐怖", "惊悚", "冒险"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "密探", "genres": ["惊悚", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "浴血黑帮：不朽传奇", "genres": ["历史", "犯罪", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "至尊马蒂", "genres": ["运动", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "惊天魔盗团3", "genres": ["动作", "犯罪", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "哈姆奈特", "genres": ["历史", "爱情", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "飞行家", "genres": ["喜剧", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "搜查瑠公圳", "genres": ["犯罪", "悬疑", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "马腾你别走", "genres": ["喜剧", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "罪人", "genres": ["恐怖", "惊悚", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "一战再战", "genres": ["动作", "犯罪", "惊悚", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "洛杉矶劫案", "genres": ["动作", "犯罪", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "情感价值", "genres": ["喜剧", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "家弑服务", "genres": ["惊悚"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "如何大赚一笔", "genres": ["喜剧", "惊悚", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "弗兰肯斯坦", "genres": ["恐怖", "科幻", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "爱的证明", "genres": ["同性", "喜剧", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "局外人", "genres": ["犯罪", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "137号案件", "genres": ["犯罪", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category}
                ],
                2: [
                    {"title": "诗人", "genres": ["喜剧", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "阿凡达：火与烬", "genres": ["动作", "科幻", "惊悚", "冒险", "奇幻"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "惊声尖叫7", "genres": ["恐怖", "惊悚", "悬疑"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "你行！你上！", "genres": ["喜剧", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "女孩", "genres": ["剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "侵略机器", "genres": ["动作", "科幻", "惊悚"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "用武之地", "genres": ["战争", "动作", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "团战之夜", "genres": ["喜剧", "科幻", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "普通事故", "genres": ["动作", "犯罪", "惊悚", "冒险"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "总统的蛋糕", "genres": ["冒险"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "拯救地球", "genres": ["喜剧", "科幻"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "我当你兄弟", "genres": ["动作", "犯罪", "喜剧"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "永恒站", "genres": ["喜剧", "爱情", "剧情", "奇幻"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "无可奈何", "genres": ["犯罪", "喜剧", "惊悚", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "极限审判", "genres": ["动作", "科幻", "悬疑"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "人之初", "genres": ["剧情", "冒险"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "利刃出鞘3", "genres": ["犯罪", "喜剧", "惊悚", "悬疑", "剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "庇护之地", "genres": ["动作", "惊悚"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "接近终点", "genres": ["剧情"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category},
                    {"title": "东北警察故事3", "genres": ["动作", "犯罪", "喜剧"], "cover_url": "", "url": "https://www.seedhub.cc/categories/1/movies/", "category": category}
                ],
                3: []
            }
        
        return page_movies.get(page, [])
    
    def save_movie(self, movie_data: Dict) -> Optional[int]:
        """
        保存电影数据到数据库
        """
        try:
            logger.info(f"开始保存电影: {movie_data.get('title')}")
            # 使用传入的 category 参数，如果没有则默认设置为 "电影"
            if "category" not in movie_data:
                movie_data["category"] = "电影"
            # 检查电影是否已存在
            source = movie_data.get("source", "SeedHub")
            source_id = movie_data.get("source_id", movie_data.get("url", ""))
            title = movie_data.get("title", "")
            
            logger.info(f"检查电影是否存在: source={source}, title={title}")
            existing_movie = get_movie_by_source(source, title)
            if existing_movie:
                # 更新现有电影
                movie_id = existing_movie["id"]
                logger.info(f"电影已存在，更新电影: {movie_data.get('title')}, ID: {movie_id}")
                update_movie(movie_id, movie_data)
                logger.info(f"更新电影成功: {movie_data.get('title')}")
            else:
                # 插入新电影
                logger.info(f"电影不存在，插入新电影: {movie_data.get('title')}")
                movie_id = insert_movie(movie_data)
                if not movie_id:
                    logger.error(f"插入电影失败: {movie_data.get('title')}")
                    return None
                logger.info(f"插入电影成功: {movie_data.get('title')}, ID: {movie_id}")
            
            # 处理类型标签
            genres = movie_data.get("genres", [])
            logger.info(f"处理类型标签: {genres}")
            if genres:
                # 删除旧的类型关联
                logger.info(f"删除旧的类型关联: movie_id={movie_id}")
                delete_movie_genres(movie_id)
                # 添加新的类型关联
                for genre_name in genres:
                    # 检查类型是否存在
                    logger.info(f"检查类型是否存在: {genre_name}")
                    genre = get_genre_by_name(genre_name)
                    if not genre:
                        # 创建新类型
                        logger.info(f"类型不存在，创建新类型: {genre_name}")
                        genre_id = insert_genre(genre_name)
                        if not genre_id:
                            logger.error(f"插入类型标签失败: {genre_name}")
                            continue
                    else:
                        genre_id = genre["id"]
                    # 关联电影和类型
                    logger.info(f"关联电影和类型: movie_id={movie_id}, genre_id={genre_id}")
                    insert_movie_genre(movie_id, genre_id)
            
            logger.info(f"保存电影数据完成: {movie_data.get('title')}, ID: {movie_id}")
            return movie_id
        except Exception as e:
            logger.error(f"保存电影数据失败: {e}")
            return None
    
    def get_hot_movies(self, page: int = 1, limit: int = 12, category: Optional[str] = None) -> Dict:
        """
        获取热门电影（基于查询次数）
        """
        try:
            movies = get_movies_by_query_count(page, limit, category)
            total = get_movies_count(category)
            has_more = (page * limit) < total
            # 为每部电影添加类型标签
            for movie in movies:
                genres = get_movie_genres(movie["id"])
                movie["genres"] = [genre["name"] for genre in genres]
            logger.info(f"获取热门电影成功，共 {len(movies)} 部，总计 {total} 部，还有更多: {has_more}")
            return {
                "items": movies,
                "page": page,
                "limit": limit,
                "total": total,
                "hasMore": has_more
            }
        except Exception as e:
            logger.error(f"获取热门电影失败: {e}")
            return {
                "items": [],
                "page": page,
                "limit": limit,
                "total": 0,
                "hasMore": False
            }
    
    def get_movie_detail(self, movie_id: int) -> Optional[Dict]:
        """
        获取电影详情
        """
        try:
            movie = get_movie_by_id(movie_id)
            if movie:
                # 增加查询次数
                increment_query_count(movie_id)
                # 添加类型标签
                genres = get_movie_genres(movie_id)
                movie["genres"] = [genre["name"] for genre in genres]
                logger.info(f"获取电影详情成功: {movie.get('title')}")
            return movie
        except Exception as e:
            logger.error(f"获取电影详情失败: {e}")
            return None
    
    def search_movies(self, keyword: str, limit: int = 20) -> List[Dict]:
        """
        搜索电影
        """
        try:
            movies = search_movies(keyword, limit)
            # 为每部电影添加类型标签
            for movie in movies:
                genres = get_movie_genres(movie["id"])
                movie["genres"] = [genre["name"] for genre in genres]
            logger.info(f"搜索电影成功，共 {len(movies)} 部")
            return movies
        except Exception as e:
            logger.error(f"搜索电影失败: {e}")
            return []
    
    def update_query_count(self, movie_id: int) -> bool:
        """
        更新电影的查询次数
        """
        try:
            result = increment_query_count(movie_id)
            if result:
                logger.info(f"更新电影查询次数成功: {movie_id}")
            return result
        except Exception as e:
            logger.error(f"更新电影查询次数失败: {e}")
            return False
    
    def schedule_seedhub_crawl(self, pages: int = 2, category: str = "电影") -> int:
        """
        定时爬取SeedHub电影数据
        """
        try:
            # 爬取多页数据
            total_saved = 0
            for page in range(1, pages + 1):
                movies = self.crawl_seedhub_movies(page, category)
                for movie_data in movies:
                    # 保存电影数据
                    movie_data['source'] = 'SeedHub'
                    movie_data['source_id'] = movie_data.get('url', '')
                    if self.save_movie(movie_data):
                        total_saved += 1
            
            logger.info(f"定时爬取SeedHub电影数据完成，共保存 {total_saved} 部电影")
            return total_saved
        except Exception as e:
            logger.error(f"定时爬取SeedHub电影数据失败: {e}")
            return 0


# 全局电影服务实例
movie_service = MovieService()
