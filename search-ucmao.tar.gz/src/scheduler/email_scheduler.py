import logging
import threading
from datetime import datetime, timedelta

from src.services.email_service import EmailService
from src.db.cookie_config_dao import get_cookie_by_cloud_name

logger = logging.getLogger(__name__)

_email_scheduler_thread = None
_email_stop_event = threading.Event()


def send_cookie_expired_email(expired_cookies: list):
    """
    发送云盘Cookie过期通知邮件
    :param expired_cookies: 过期的Cookie列表
    """
    try:
        email_service = EmailService()
        subject = "桃白白影视 - 云盘Cookie过期通知"
        
        cookies_list_html = ""
        for cookie_info in expired_cookies:
            cookies_list_html += f"<p>• <strong>{cookie_info['name']}</strong></p>"
        
        body = f"""
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px; border-radius: 12px;">
            <div style="background: white; padding: 30px; border-radius: 8px; text-align: center;">
                <h1 style="color: #333; font-size: 28px; margin-bottom: 20px;">🎬 桃白白影视</h1>
                <div style="font-size: 18px; color: #555; margin: 20px 0; line-height: 1.8; text-align: left;">
                    <p style="color: #e74c3c; font-weight: bold; font-size: 20px; text-align: center;">
                        检测到云盘Cookie已过期！
                    </p>
                    <p><strong>时间:</strong> {datetime.now().strftime('%Y年%m月%d日 %H:%M:%S')}</p>
                    <p><strong>过期的Cookie:</strong></p>
                    {cookies_list_html}
                    <p style="margin-top: 20px; color: #e74c3c;">
                        请及时更新云盘Cookie，否则洗白功能将无法正常使用！
                    </p>
                </div>
                <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; color: #999; font-size: 14px;">
                    <p>桃白白影视 - 让每一份网盘资源都为你创造价值</p>
                </div>
            </div>
        </div>
        """
        
        success, message = email_service.send_notification(subject, body)
        
        if success:
            logger.info(f"[邮件通知] 云盘Cookie过期通知邮件发送成功")
        else:
            logger.warning(f"[邮件通知] 云盘Cookie过期通知邮件发送失败: {message}")
    except Exception as e:
        logger.error(f"[邮件通知] 发送云盘Cookie过期通知邮件时出错: {e}", exc_info=True)


def check_cookies_expired():
    """
    检查云盘Cookie是否过期
    :return: 过期的Cookie列表
    """
    expired_cookies = []
    
    try:
        # 检查夸克网盘Cookie
        quark_cookie = get_cookie_by_cloud_name("夸克网盘")
        if not quark_cookie or len(quark_cookie) < 300:
            expired_cookies.append({"name": "夸克网盘", "cookie": quark_cookie})
            logger.warning("[邮件通知] 夸克网盘Cookie已过期或未配置")
        
        # 检查百度网盘Cookie
        baidu_cookie = get_cookie_by_cloud_name("百度网盘")
        if not baidu_cookie or len(baidu_cookie) < 300:
            expired_cookies.append({"name": "百度网盘", "cookie": baidu_cookie})
            logger.warning("[邮件通知] 百度网盘Cookie已过期或未配置")
        
    except Exception as e:
        logger.error(f"[邮件通知] 检查Cookie过期状态时出错: {e}", exc_info=True)
    
    return expired_cookies


def send_cookie_reminder_email():
    """
    发送更换云盘Cookie提醒邮件
    """
    try:
        email_service = EmailService()
        subject = "桃白白影视 - 云盘Cookie提醒"
        body = """
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px; border-radius: 12px;">
            <div style="background: white; padding: 30px; border-radius: 8px; text-align: center;">
                <h1 style="color: #333; font-size: 28px; margin-bottom: 20px;">🎬 桃白白影视</h1>
                <div style="font-size: 18px; color: #555; margin: 20px 0; line-height: 1.8;">
                    <p>您好！</p>
                    <p>今天是 <strong>{date}</strong>，</p>
                    <p>提醒您：</p>
                    <p style="font-size: 20px; color: #e74c3c; font-weight: bold;">
                        请及时更换云盘Cookie，防止过期！
                    </p>
                </div>
                <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; color: #999; font-size: 14px;">
                    <p>桃白白影视 - 让每一份网盘资源都为你创造价值</p>
                </div>
            </div>
        </div>
        """.format(date=datetime.now().strftime('%Y年%m月%d日'))
        
        success, message = email_service.send_notification(subject, body)
        
        if success:
            logger.info(f"[邮件通知] 云盘Cookie提醒邮件发送成功")
        else:
            logger.warning(f"[邮件通知] 云盘Cookie提醒邮件发送失败: {message}")
    except Exception as e:
        logger.error(f"[邮件通知] 发送云盘Cookie提醒邮件时出错: {e}", exc_info=True)


def send_wash_failed_email(reason: str, url: str, title: str = ""):
    """
    发送洗白失败邮件通知
    :param reason: 失败原因
    :param url: 原始链接
    :param title: 标题
    """
    try:
        email_service = EmailService()
        subject = "桃白白影视 - 洗白失败通知"
        body = """
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px; border-radius: 12px;">
            <div style="background: white; padding: 30px; border-radius: 8px; text-align: center;">
                <h1 style="color: #333; font-size: 28px; margin-bottom: 20px;">🎬 桃白白影视</h1>
                <div style="font-size: 18px; color: #555; margin: 20px 0; line-height: 1.8; text-align: left;">
                    <p style="color: #e74c3c; font-weight: bold; font-size: 20px; text-align: center;">
                        洗白失败！
                    </p>
                    <p><strong>时间:</strong> {time}</p>
                    <p><strong>标题:</strong> {title}</p>
                    <p><strong>链接:</strong> {url}</p>
                    <p><strong>原因:</strong> <span style="color: #e74c3c;">{reason}</span></p>
                </div>
                <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; color: #999; font-size: 14px;">
                    <p>桃白白影视 - 让每一份网盘资源都为你创造价值</p>
                </div>
            </div>
        </div>
        """.format(
            time=datetime.now().strftime('%Y年%m月%d日 %H:%M:%S'),
            title=title or "无标题",
            url=url,
            reason=reason
        )
        
        success, message = email_service.send_notification(subject, body)
        
        if success:
            logger.info(f"[邮件通知] 洗白失败邮件发送成功: {title}")
        else:
            logger.warning(f"[邮件通知] 洗白失败邮件发送失败: {message}")
    except Exception as e:
        logger.error(f"[邮件通知] 发送洗白失败邮件时出错: {e}", exc_info=True)


def _email_scheduler_loop():
    """
    邮件通知任务循环
    1. 每天0点检查云盘Cookie是否过期
    2. 每月20号9点发送更换云盘Cookie提醒
    """
    while not _email_stop_event.is_set():
        try:
            now = datetime.now()
            
            # 检查是否是每天0点
            if now.hour == 0 and now.minute == 0:
                logger.info(f"[邮件通知] 每天0点检查云盘Cookie过期状态")
                expired_cookies = check_cookies_expired()
                
                if expired_cookies:
                    logger.info(f"[邮件通知] 检测到 {len(expired_cookies)} 个过期的Cookie，发送邮件通知")
                    send_cookie_expired_email(expired_cookies)
                else:
                    logger.info("[邮件通知] 所有云盘Cookie状态正常")
                
                # 等待到明天再检查
                tomorrow = datetime(now.year, now.month, now.day) + timedelta(days=1)
                seconds_until_tomorrow = (tomorrow - now).total_seconds()
                
                logger.info(f"[邮件通知] 等待到明天再检查，需要等待 {seconds_until_tomorrow:.2f} 秒")
                if _email_stop_event.wait(seconds_until_tomorrow):
                    break
                continue
            
            # 检查是否是每月20号
            if now.day == 20:
                # 检查是否已经在今天发送过
                # 简单的方式：每天只在9点检查一次
                if now.hour == 9:
                    logger.info(f"[邮件通知] 今天是每月20号，发送云盘Cookie提醒邮件")
                    send_cookie_reminder_email()
                    
                    # 等待到明天再检查
                    tomorrow = datetime(now.year, now.month, now.day) + timedelta(days=1)
                    seconds_until_tomorrow = (tomorrow - now).total_seconds()
                    
                    logger.info(f"[邮件通知] 等待到明天再检查，需要等待 {{seconds_until_tomorrow:.2f}} 秒")
                    if _email_stop_event.wait(seconds_until_tomorrow):
                        break
                    continue
            
            # 计算到下一个小时的时间
            next_hour = datetime(now.year, now.month, now.day, now.hour) + timedelta(hours=1)
            seconds_until_next_hour = (next_hour - now).total_seconds()
            
            logger.debug(f"[邮件通知] 等待到下一个小时检查，需要等待 {{seconds_until_next_hour:.2f}} 秒")
            
            if _email_stop_event.wait(seconds_until_next_hour):
                break
                
        except Exception as e:
            logger.error(f"[邮件通知] 邮件通知任务执行异常: {e}", exc_info=True)
            # 出错后等待1小时再继续
            _email_stop_event.wait(3600)


def start_email_scheduler():
    """
    启动邮件通知定时任务
    """
    global _email_scheduler_thread, _email_stop_event
    
    if _email_scheduler_thread and _email_scheduler_thread.is_alive():
        logger.warning("[邮件通知] 邮件通知调度器已在运行中")
        return
    
    _email_stop_event.clear()
    _email_scheduler_thread = threading.Thread(
        target=_email_scheduler_loop,
        daemon=True
    )
    _email_scheduler_thread.start()
    logger.info("[邮件通知] 邮件通知调度器已启动: 每月20号9点发送云盘Cookie提醒")


def stop_email_scheduler():
    """
    停止邮件通知定时任务
    """
    global _email_stop_event
    
    _email_stop_event.set()
    logger.info("[邮件通知] 邮件通知调度器已停止")
