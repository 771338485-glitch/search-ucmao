# routes/search_routes.py

from flask import Blueprint, request, jsonify, Response

import logging
import asyncio

from src.pan_operator import create_share, del_share
from src.services.search_service import (
    generate_search_stream_events,
    search_resources,
)

logger = logging.getLogger(__name__)

search_bp = Blueprint("search", __name__)


@search_bp.route("/api/search_stream", methods=["GET"])
def search_stream():
    """
    使用 Server-Sent Events (SSE) 实时流式返回搜索结果。
    """
    keyword = request.args.get("keyword")
    if not keyword:
        return jsonify({"error": "请提供搜索关键词"}), 400

    logger.info(f"用户 SSE 搜索关键词: {keyword}")
    
    # 获取用户 IP 地址
    ip_address = request.remote_addr
    logger.info(f"原始 remote_addr: {ip_address}")
    
    # 检查 X-Forwarded-For（代理转发时使用）
    x_forwarded_for = request.headers.get('X-Forwarded-For')
    logger.info(f"X-Forwarded-For: {x_forwarded_for}")
    if x_forwarded_for:
        # X-Forwarded-For 格式: client, proxy1, proxy2, ...
        # 取第一个有效的 IP
        ips = [ip.strip() for ip in x_forwarded_for.split(',') if ip.strip()]
        if ips:
            ip_address = ips[0]
            logger.info(f"从 X-Forwarded-For 获取到 IP: {ip_address}")
    
    # 检查其他常见的代理头
    if not ip_address or ip_address == "unknown":
        ip_address = request.headers.get('X-Real-IP', request.remote_addr)
        logger.info(f"从 X-Real-IP 获取到 IP: {ip_address}")
    if not ip_address or ip_address == "unknown":
        ip_address = request.headers.get('CF-Connecting-IP', request.remote_addr)
        logger.info(f"从 CF-Connecting-IP 获取到 IP: {ip_address}")
    
    # 尝试获取客户端的真实 IP 地址
    # 检查是否有其他可能的头信息
    if not ip_address or ip_address == "unknown" or ip_address.startswith('127.'):
        # 检查是否有其他代理头
        other_headers = [
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_CLIENT_IP',
            'REMOTE_ADDR'
        ]
        for header in other_headers:
            if header in request.environ:
                header_value = request.environ.get(header)
                if header_value and header_value != "unknown" and not header_value.startswith('127.'):
                    ip_address = header_value
                    logger.info(f"从 {header} 获取到 IP: {ip_address}")
                    break
        
        # 如果仍然是本地回环地址，保持为127.0.0.1
        # 不尝试获取服务器的局域网IP地址，因为这会导致记录的IP不准确
        if ip_address.startswith('127.'):
            logger.info(f"使用本地回环地址: {ip_address}")
    
    logger.info(f"最终使用的 IP 地址: {ip_address}")
    
    # 记录搜索历史（异步，不影响搜索速度）
    try:
        from src.db.search_history_dao import add_search_history
        import threading
        threading.Thread(target=add_search_history, args=(ip_address, keyword)).start()
    except Exception as e:
        logger.warning(f"记录搜索历史失败: {e}")

    def generate_events():
        for payload in generate_search_stream_events(keyword):
            yield f"data: {payload}\n\n"

    response = Response(generate_events(), mimetype="text/event-stream")
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    response.headers['X-Accel-Buffering'] = 'no'  # 禁用 Nginx 缓冲
    return response


@search_bp.route("/api", methods=["GET"])
def search_api():
    """
    通过名称、云名称或类型搜索资源的API接口
    """
    name = request.args.get("name", "", type=str)
    cloud_name = request.args.get("cloud_name", "", type=str)
    resource_type = request.args.get("type", "", type=str)
    limit = request.args.get("limit", 100, type=int)
    sort = request.args.get("sort", "default")

    success, message, results = search_resources(
        name=name, cloud_name=cloud_name, resource_type=resource_type, limit=limit, sort=sort
    )

    if not success:
        status_code = 400 if "至少需要提供" in message else 500
        return jsonify({"success": False, "message": message}), status_code

    return jsonify({"success": True, "total": len(results), "results": results})


@search_bp.route("/create_share", methods=["POST"])
def create_share_route():
    try:
        share_data = request.get_json()
        if not share_data:
            return jsonify({"error": "缺少参数"}), 400
        result = create_share(share_data)
        if result:
            logger.info(f"分享创建成功: {share_data.get('title')}")
            return jsonify({"message": '分享创建成功', "success": True, "data": result}), 200
        else:
            logger.warning(f"分享创建失败: {share_data.get('title')}")
            return jsonify({"error": "分享创建失败"}), 500
    except Exception as e:
        logger.error(f"创建分享时发生未知错误: {str(e)}", exc_info=True)
        return jsonify({"error": f"发生未知错误: {str(e)}"}), 500


@search_bp.route("/api/wash", methods=["POST"])
def wash_single_link():
    """手动洗白单条链接"""
    try:
        data = request.get_json()
        url = data.get("url") or data.get("share_url")
        title = data.get("title", "")
        
        if not url:
            return jsonify({"success": False, "message": "缺少链接参数"}), 400
        
        from utils.netdisk_utils import match_netdisk_link
        netdisk_name = match_netdisk_link(url)
        
        share_data = {
            "share_url": url,
            "title": title,
            "cloud_name": netdisk_name,
            "save_to_netdisk": {"quark": True, "baidu": True}
        }
        
        result = create_share(share_data)
        
        if result and result.get("share_url"):
            logger.info(f"[手动洗白] 成功: {title} -> {result['share_url']}")
            return jsonify({
                "success": True,
                "message": "洗白成功",
                "data": {
                    "original_url": url,
                    "washed_url": result["share_url"],
                    "file_id": result.get("file_id"),
                    "netdisk_name": netdisk_name
                }
            })
        else:
            # 如果洗白失败，返回原始链接
            return jsonify({
                "success": True,
                "message": "不支持洗白，返回原始链接",
                "data": {
                    "original_url": url,
                    "washed_url": url,
                    "file_id": None,
                    "netdisk_name": netdisk_name
                }
            })
            
    except Exception as e:
        logger.error(f"手动洗白失败: {str(e)}", exc_info=True)
        return jsonify({"success": False, "message": f"洗白失败: {str(e)}"}), 500


@search_bp.route("/del_share", methods=["POST"])
def del_share_route():
    try:
        share_data = request.get_json()
        if not share_data:
            return jsonify({"error": "缺少参数"}), 400
        result = del_share(share_data)
        if result:
            logger.info(f"分享删除成功: URL={share_data.get('share_url')}")
            return jsonify({"message": "分享删除成功", "success": True}), 200
            logger.warning(f"分享删除失败: URL={share_data.get('share_url')}")
            return jsonify({"error": "分享删除失败"}), 500
    except Exception as e:
        logger.error(f"删除分享时发生未知错误: {str(e)}", exc_info=True)
        return jsonify({"error": f"发生未知错误: {str(e)}"}), 500


@search_bp.route("/api/check_validity", methods=["POST"])
def check_validity():
    """检查单个链接的有效性"""
    try:
        data = request.get_json()
        url = data.get("url")
        
        if not url:
            return jsonify({"success": False, "message": "缺少链接参数"}), 400
        
        from utils.netdisk_utils import check_link_validity
        is_valid = check_link_validity(url)
        
        return jsonify({
            "success": True,
            "data": {
                "url": url,
                "is_valid": is_valid
            }
        })
    except Exception as e:
        logger.error(f"检查链接有效性失败: {str(e)}", exc_info=True)
        return jsonify({"success": False, "message": f"检查失败: {str(e)}"}), 500


@search_bp.route("/api/check_validity_batch", methods=["POST"])
async def check_validity_batch():
    """批量检查链接的有效性"""
    try:
        data = request.get_json()
        urls = data.get("urls", [])
        
        if not urls or not isinstance(urls, list):
            return jsonify({"success": False, "message": "缺少链接参数或参数格式错误"}), 400
        
        from utils.netdisk_utils import check_link_validity_async
        results = []
        
        # 最多处理50个链接，避免服务器负载过高
        batch_urls = urls[:50]
        
        # 并发处理所有链接
        tasks = []
        for url in batch_urls:
            task = check_link_validity_async(url)
            tasks.append(task)
        
        # 等待所有任务完成
        validities = await asyncio.gather(*tasks, return_exceptions=True)
        
        # 处理结果
        for i, url in enumerate(batch_urls):
            try:
                is_valid = validities[i]
                if isinstance(is_valid, Exception):
                    logger.error(f"检查链接有效性失败: {url} (错误: {is_valid})")
                    results.append({
                        "url": url,
                        "is_valid": False  # 出错时默认为无效
                    })
                else:
                    results.append({
                        "url": url,
                        "is_valid": is_valid
                    })
            except Exception as e:
                logger.error(f"检查链接有效性失败: {url} (错误: {e})")
                results.append({
                    "url": url,
                    "is_valid": False  # 出错时默认为无效
                })
        
        return jsonify({
            "success": True,
            "data": results
        })
    except Exception as e:
        logger.error(f"批量检查链接有效性失败: {str(e)}", exc_info=True)
        return jsonify({"success": False, "message": f"检查失败: {str(e)}"}), 500