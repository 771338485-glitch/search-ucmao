import logging
from flask import Blueprint, request, jsonify

from src.services.movie_service import movie_service

logger = logging.getLogger(__name__)

# 创建蓝图
movie_bp = Blueprint('movie', __name__)


@movie_bp.route('/api/movies/hot')
def api_hot_movies():
    """
    获取热门电影API
    """
    try:
        page = request.args.get('page', 1, type=int)
        limit = request.args.get('limit', 12, type=int)
        category = request.args.get('category', None, type=str)
        result = movie_service.get_hot_movies(page, limit, category)
        
        return jsonify({
            'code': 0,
            'message': 'success',
            'data': result
        })
    except Exception as e:
        logger.error(f"获取热门电影失败: {e}")
        return jsonify({
            'code': -1,
            'message': f'获取热门电影失败: {str(e)}',
            'data': {
                'items': [],
                'page': 1,
                'limit': 12,
                'total': 0,
                'hasMore': False
            }
        })


@movie_bp.route('/api/movies/detail/<int:movie_id>')
def api_movie_detail(movie_id):
    """
    获取电影详情API
    """
    try:
        movie = movie_service.get_movie_detail(movie_id)
        
        if movie:
            return jsonify({
                'code': 0,
                'message': 'success',
                'data': movie
            })
        else:
            return jsonify({
                'code': -1,
                'message': '电影不存在',
                'data': None
            })
    except Exception as e:
        logger.error(f"获取电影详情失败: {e}")
        return jsonify({
            'code': -1,
            'message': f'获取电影详情失败: {str(e)}',
            'data': None
        })


@movie_bp.route('/api/movies/search')
def api_search_movies():
    """
    搜索电影API
    """
    try:
        keyword = request.args.get('keyword', '', type=str)
        limit = request.args.get('limit', 20, type=int)
        
        if not keyword:
            return jsonify({
                'code': -1,
                'message': '搜索关键词不能为空',
                'data': {
                    'items': []
                }
            })
        
        movies = movie_service.search_movies(keyword, limit)
        
        return jsonify({
            'code': 0,
            'message': 'success',
            'data': {
                'items': movies,
                'keyword': keyword,
                'limit': limit
            }
        })
    except Exception as e:
        logger.error(f"搜索电影失败: {e}")
        return jsonify({
            'code': -1,
            'message': f'搜索电影失败: {str(e)}',
            'data': {
                'items': []
            }
        })


@movie_bp.route('/api/movies/crawl')
def api_crawl_movies():
    """
    爬取电影数据API
    """
    try:
        pages = request.args.get('pages', 2, type=int)
        category = request.args.get('category', '电影', type=str)
        saved_count = movie_service.schedule_seedhub_crawl(pages, category)
        
        return jsonify({
            'code': 0,
            'message': 'success',
            'data': {
                'saved_count': saved_count,
                'pages': pages,
                'category': category
            }
        })
    except Exception as e:
        logger.error(f"爬取电影数据失败: {e}")
        return jsonify({
            'code': -1,
            'message': f'爬取电影数据失败: {str(e)}',
            'data': {
                'saved_count': 0,
                'pages': 0,
                'category': '电影'
            }
        })
