"""
邮件配置路由
"""

from flask import Blueprint, jsonify, request
import logging
from src.db.email_config_dao import EmailConfigDAO
from src.services.email_service import get_email_service

logger = logging.getLogger(__name__)

email_config_bp = Blueprint('email_config', __name__)

email_config_dao = EmailConfigDAO()
email_service = get_email_service()


@email_config_bp.route('/api/email/config', methods=['GET'])
def get_email_config():
    """
    获取邮件配置
    """
    try:
        config = email_config_dao.get_config()
        return jsonify({
            'success': True,
            'config': config
        })
    except Exception as e:
        logger.error(f"获取邮件配置失败: {e}")
        return jsonify({
            'success': False,
            'message': f'获取配置失败: {str(e)}'
        }), 500


@email_config_bp.route('/api/email/config', methods=['POST'])
def save_email_config():
    """
    保存邮件配置
    """
    try:
        config = request.get_json()
        if not config:
            return jsonify({
                'success': False,
                'message': '请求数据为空'
            }), 400
        
        success, message = email_config_dao.save_config(config)
        
        return jsonify({
            'success': success,
            'message': message
        })
    except Exception as e:
        logger.error(f"保存邮件配置失败: {e}")
        return jsonify({
            'success': False,
            'message': f'保存配置失败: {str(e)}'
        }), 500


@email_config_bp.route('/api/email/test', methods=['POST'])
def send_test_email():
    """
    发送测试邮件
    """
    try:
        success, message = email_service.send_test_email()
        
        return jsonify({
            'success': success,
            'message': message
        })
    except Exception as e:
        logger.error(f"发送测试邮件失败: {e}")
        return jsonify({
            'success': False,
            'message': f'发送失败: {str(e)}'
        }), 500
