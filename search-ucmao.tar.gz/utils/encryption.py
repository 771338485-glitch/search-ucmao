import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
import base64

from configs.app_config import ENCRYPTION_KEY

class EncryptionUtils:
    """加密工具类"""
    
    def __init__(self, key=None):
        # 使用配置的密钥或默认密钥
        self.key = key or ENCRYPTION_KEY.encode()
        # 确保密钥长度为16、24或32字节
        if len(self.key) not in [16, 24, 32]:
            # 填充或截断密钥
            self.key = self.key.ljust(32)[:32]
        self.backend = default_backend()
    
    def encrypt(self, plaintext):
        """加密文本"""
        if not plaintext:
            return None
        
        # 生成随机IV
        iv = os.urandom(16)
        
        # 创建加密器
        cipher = Cipher(algorithms.AES(self.key), modes.CBC(iv), backend=self.backend)
        encryptor = cipher.encryptor()
        
        # 对数据进行填充
        padder = padding.PKCS7(128).padder()
        padded_data = padder.update(plaintext.encode()) + padder.finalize()
        
        # 加密数据
        ciphertext = encryptor.update(padded_data) + encryptor.finalize()
        
        # 将IV和密文组合并base64编码
        return base64.b64encode(iv + ciphertext).decode()
    
    def decrypt(self, ciphertext):
        """解密文本"""
        if not ciphertext:
            return None
        
        try:
            # 解码base64
            encrypted_data = base64.b64decode(ciphertext)
            
            # 提取IV和密文
            iv = encrypted_data[:16]
            ciphertext = encrypted_data[16:]
            
            # 创建解密器
            cipher = Cipher(algorithms.AES(self.key), modes.CBC(iv), backend=self.backend)
            decryptor = cipher.decryptor()
            
            # 解密数据
            padded_plaintext = decryptor.update(ciphertext) + decryptor.finalize()
            
            # 移除填充
            unpadder = padding.PKCS7(128).unpadder()
            plaintext = unpadder.update(padded_plaintext) + unpadder.finalize()
            
            return plaintext.decode()
        except Exception as e:
            print(f"解密失败: {e}")
            return None

# 创建全局加密工具实例
encryption_utils = EncryptionUtils()
