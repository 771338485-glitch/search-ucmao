// --- 全局状态管理和 DOM 元素 ---
let allResults = [];
let isSearchRunning = false;
let currentPage = 1;
const itemsPerPage = 20;
let isLoadingNextBatch = false;
let isFullyLoaded = false;
let validityCheckInterval = null;
let currentFilter = '全部';

// DOM 元素引用
let filterBar, scrollableResultsDiv, searchButton, searchInput, resultContainer, loadingMore, resultCountText, statusBar;

// 页面加载时检查 URL 是否包含 keyword 参数
function checkUrlForKeyword() {
    // 初始化 DOM 元素引用
    filterBar = document.getElementById('netdisk-filter-bar');
    scrollableResultsDiv = document.getElementById('scrollableResults');
    searchButton = document.getElementById('searchButton');
    searchInput = document.getElementById('searchInput');
    resultContainer = document.getElementById('resultContainer');
    loadingMore = document.getElementById('loadingMore');
    resultCountText = document.getElementById('resultCountText');
    statusBar = document.getElementById('statusBar');
    
    // 绑定搜索按钮事件
    if (searchButton) {
        searchButton.addEventListener('click', performSearch);
    }
    
    // 绑定搜索输入框回车事件
    if (searchInput) {
        searchInput.addEventListener('keydown', function (event) {
            if (event.key === 'Enter') {
                performSearch();
            }
        });
    }
    
    // 绑定网盘过滤事件
    if (filterBar) {
        filterBar.addEventListener('click', (event) => {
            const button = event.target.closest('.filter-btn');
            if (button) {
                const netdisk = button.getAttribute('data-netdisk');
                if (netdisk === currentFilter) return;
                currentFilter = netdisk;
                filterBar.querySelectorAll('.filter-btn').forEach(btn => {
                    btn.classList.remove('active');
                });
                button.classList.add('active');
                renderResults(true);
                if (scrollableResultsDiv) {
                    scrollableResultsDiv.scrollTop = 0;
                }
            }
        });
    }
    
    // 检查 URL 参数
    const urlParams = new URLSearchParams(window.location.search);
    const keyword = urlParams.get('keyword');
    if (keyword && searchInput) {
        searchInput.value = keyword;
    }
}

// 页面加载完成后检查 URL 参数
document.addEventListener('DOMContentLoaded', function() {
    // 先初始化DOM元素
    checkUrlForKeyword();
    
    // 然后延迟执行搜索，确保页面完全渲染
    const urlParams = new URLSearchParams(window.location.search);
    const keyword = urlParams.get('keyword');
    if (keyword) {
        setTimeout(function() {
            if (searchInput) {
                searchInput.value = keyword;
                performSearch();
            }
        }, 1000);
    }
});


// --- 辅助函数：网盘颜色区分 (保持不变) ---
function getNetdiskColorClass(netdiskName) {
    let badgeClass = 'bg-secondary';
    let badgeTextClass = 'text-white';

    if (netdiskName.includes('百度网盘')) badgeClass = 'bg-mid-blue';
    else if (netdiskName.includes('夸克网盘')) badgeClass = 'bg-terracotta';
    else if (netdiskName.includes('悟空网盘')) badgeClass = 'bg-navy-blue';
    else if (netdiskName.includes('快兔网盘')) badgeClass = 'bg-coral';
    else if (netdiskName.includes('115网盘')) badgeClass = 'bg-orange';
    else if (netdiskName.includes('迅雷网盘')) badgeClass = 'bg-teal';
    else if (netdiskName.includes('UC网盘')) badgeClass = 'bg-warm-gold';
    else if (netdiskName.includes('移动云盘')) badgeClass = 'bg-light-green';
    else if (netdiskName.includes('天翼云盘')) badgeClass = 'bg-deep-violet';
    else if (netdiskName.includes('123云盘')) badgeClass = 'bg-purple';
    else if (netdiskName.includes('阿里云盘')) badgeClass = 'bg-dark-mint';
    else if (netdiskName.includes('联通云盘')) badgeClass = 'bg-olive';
        else if (netdiskName.includes('PikPak')) badgeClass = 'bg-salmon';
    else if (netdiskName.includes('磁力链接') || netdiskName.includes('迅雷链接') || netdiskName.includes('电驴链接')) badgeClass = 'bg-dark';

    if (badgeClass !== 'bg-warning') {
        badgeTextClass = 'text-white';
    }

    return { badgeClass, badgeTextClass };
}

// 前端去重辅助函数 (保持不变)
function filterUnique2ndDomainFront(lst) {
    const seenCombinations = new Set();
    const result = [];
    for (const subList of lst) {
        if (subList.length >= 4) {
            const title = subList[1];
            const url = subList[2];
            try {
                let domain = '';
                if (url.startsWith('http://') || url.startsWith('https://')) {
                    const urlObj = new URL(url);
                    domain = urlObj.hostname;
                } else {
                    domain = url;
                }
                const combination = `${title}|${domain}`;
                if (!seenCombinations.has(combination)) {
                    seenCombinations.add(combination);
                    result.push(subList);
                }
            } catch (e) {
                const combination = `${title}|${url}`;
                if (!seenCombinations.has(combination)) {
                    seenCombinations.add(combination);
                    result.push(subList);
                }
            }
        }
    }
    return result;
}

// --- 搜索和结果管理 ---

/**
 * 动态创建网盘过滤按钮。
 */
function updateFilterButtons() {
    if (!filterBar) return;
    
    const netdiskNames = new Set(allResults.map(item => item[3]));
    const buttonsToRemove = Array.from(filterBar.querySelectorAll('.filter-btn')).filter(btn => btn.getAttribute('data-netdisk') !== '全部');
    buttonsToRemove.forEach(btn => btn.remove());

    if (allResults.length > 0) {
        filterBar.classList.remove('d-none');
        if (resultCountText) {
            resultCountText.classList.add('d-none');
        }
    } else {
         filterBar.classList.add('d-none');
    }

    const countByNetdisk = {};
    allResults.forEach(item => {
        const netdisk = item[3];
        countByNetdisk[netdisk] = (countByNetdisk[netdisk] || 0) + 1;
    });
    countByNetdisk['全部'] = allResults.length;

    const dynamicNames = Array.from(netdiskNames).filter(name => name !== '全部' && name !== '其他');

    dynamicNames.forEach(name => {
        const button = document.createElement('button');
        button.className = 'filter-btn';
        button.innerHTML = `${name} (${countByNetdisk[name] || 0})`;
        button.setAttribute('data-netdisk', name);

        if (name === currentFilter) {
            button.classList.add('active');
        }
        filterBar.appendChild(button);
    });

    const hasOther = netdiskNames.has('其他');
    if (hasOther) {
        const otherButton = document.createElement('button');
        otherButton.className = 'filter-btn';
        otherButton.innerHTML = `其他 (${countByNetdisk['其他'] || 0})`;
        otherButton.setAttribute('data-netdisk', '其他');

        if ('其他' === currentFilter) {
            otherButton.classList.add('active');
        }
        filterBar.appendChild(otherButton);
    }

    const allButton = filterBar.querySelector('[data-netdisk="全部"]');
    if (allButton) {
        allButton.innerHTML = `全部 (${countByNetdisk['全部'] || 0})`;
        if (currentFilter === '全部') {
            allButton.classList.add('active');
        } else {
            allButton.classList.remove('active');
        }
    }

    document.querySelectorAll('.filter-btn').forEach(button => {
        button.onclick = function() {
            currentFilter = this.getAttribute('data-netdisk');
            renderResults(true);
            updateFilterButtons();
        };
    });
}

/**
 * 执行流式搜索（SSE）
 */
function performSearch() {
    if (isSearchRunning) return;
    if (!searchInput || !searchButton || !statusBar || !resultCountText || !loadingMore || !filterBar || !resultContainer || !scrollableResultsDiv) return;

    const keyword = searchInput.value;
    if (!keyword) {
        alert('请输入搜索关键词');
        return;
    }

    isSearchRunning = true;
    isFullyLoaded = false;
    searchButton.disabled = true;

    searchButton.classList.add('is-flying');
    searchButton.classList.add('searching');

    statusBar.classList.remove('d-none');
    statusBar.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status"></span> 正在持续搜索更多资源...';

    resultCountText.classList.add('d-none');
    loadingMore.classList.add('d-none');

    allResults = [];
    currentPage = 1;
    currentFilter = '全部';
    filterBar.classList.add('d-none');

    resultContainer.innerHTML = '<p class="text-center text-muted p-4">正在连接并等待结果流...</p>';
    scrollableResultsDiv.removeEventListener('scroll', infiniteScrollHandler);
    
    const doubanSection = document.getElementById('doubanHotSection');
    const filterCountContainer = document.querySelector('.filter-and-count-container');
    if (doubanSection) doubanSection.style.display = 'none';
    if (filterCountContainer) filterCountContainer.classList.remove('d-none');
    if (resultContainer) resultContainer.classList.remove('d-none');

    const eventSource = new EventSource(`/api/search_stream?keyword=${encodeURIComponent(keyword)}`);

    eventSource.onmessage = function(event) {
        try {
            const data = JSON.parse(event.data);

            if (data.type === 'end') {
                eventSource.close();
                finalizeSearch();
            } else if (data.results && data.results.length > 0) {
                const currentLength = allResults.length;
                allResults.push(...data.results);
                allResults = filterUnique2ndDomainFront(allResults);

                if (allResults.length > currentLength) {
                    updateFilterButtons();
                    if (allResults.length <= itemsPerPage) {
                        renderResults(true);
                    }
                }
            }
        } catch (error) {
            console.error('解析流数据出错:', error);
            console.error('出错的事件数据:', event.data);
        }
    };

    eventSource.onerror = function(error) {
        console.error('EventSource 错误:', error);
        eventSource.close();
        resultContainer.innerHTML = '<p class="text-center text-danger p-4">❌ 搜索连接出错或服务器异常。</p>';
        finalizeSearch(true);
    };
}

/**
 * 搜索完成或出错时的清理工作
 */
function finalizeSearch(hasError = false) {
    isSearchRunning = false;
    searchButton.disabled = false;

    searchButton.classList.remove('is-flying');
    searchButton.classList.remove('searching');

    statusBar.classList.add('d-none');

    if (allResults.length === 0 && !hasError) {
        resultContainer.innerHTML = `
            <div class="text-center initial-prompt-area">
                <div class="initial-icon-wrapper">
                    <i class="fas fa-cloud-upload-alt"></i>
                </div>
                <h3 class="mt-3 text-muted">未找到相关结果，请尝试其他关键词</h3>
            </div>`;
        loadingMore.classList.add('d-none');
        document.querySelector('.filter-and-count-container').classList.remove('d-none');
        resultCountText.classList.add('d-none');
    } else if (!hasError) {
        updateFilterButtons();
        document.querySelector('.filter-and-count-container').classList.remove('d-none');
        renderResults(true);
        scrollableResultsDiv.addEventListener('scroll', infiniteScrollHandler);
        startValidityCheck();
    }
}

/**
 * 渲染搜索结果到页面
 */
function renderResults(reset = false) {
    if (!resultContainer) return;
    
    let filteredResults = allResults.filter(result => {
        const matchesNetdisk = currentFilter === '全部' || result[3] === currentFilter;
        return matchesNetdisk;
    });

    if (reset) {
        currentPage = 1;
        resultContainer.innerHTML = '';
    }

    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const currentBatch = filteredResults.slice(startIndex, endIndex);

    if (resultCountText) {
        resultCountText.classList.add('d-none');
    }
    
    if (filteredResults.length > 0) {
        resultContainer.querySelector('p.text-center.text-muted')?.remove();
    } else if (!isSearchRunning && reset) {
        resultContainer.innerHTML = `<div class="text-center p-5"><p class="text-muted">在 ${currentFilter} 中未找到相关结果</p></div>`;
    }

    if (currentBatch.length > 0) {
        const fragment = document.createDocumentFragment();
        
        currentBatch.forEach((result, index) => {
            const source = result[0];
            const titleText = result[1];
            const urlLink = result[2];
            const netdiskName = result[3];
            const datetimeStr = result[4] || '';
            const is_valid = result[5];

            const { badgeClass, badgeTextClass } = getNetdiskColorClass(netdiskName);
            const hotClass = source === 'hot' ? 'hot-result' : '';

            const finalBadgeClass = `${badgeClass} ${badgeTextClass}`;
            
            let validityBadgeHtml = '';
            if (is_valid === true || is_valid === false) {
                const validityClass = is_valid ? 'valid-link' : 'invalid-link';
                const validityText = is_valid ? '有效' : '无效';
                validityBadgeHtml = `<span class="validity-badge ${validityClass}">${validityText}</span>`;
            }

            const fullItem = document.createElement('div');

            const itemHtml = `
                <div class="result-item ${hotClass}">
                    <div class="result-title">${titleText}</div>
                    <div class="result-meta">
                        <span class="result-datetime">${datetimeStr || ''}</span>
                        <div class="result-actions">
                            <span class="netdisk-badge ${finalBadgeClass}">${netdiskName}</span>
                            ${validityBadgeHtml}
                            <button class="btn btn-sm open-button btn-outline-primary" data-title="${titleText}" data-url="${urlLink}" data-netdisk="${netdiskName}">
                                <i class="fas fa-external-link-alt"></i> 打开
                            </button>
                        </div>
                    </div>
                </div>
                ${(startIndex + index) < filteredResults.length - 1 ? '<hr class="result-divider">' : ''}
            `;
            fullItem.innerHTML = itemHtml;
            fragment.appendChild(fullItem);
            
            const resultItem = fullItem.querySelector('.result-item');
            if (resultItem) {
                resultItem.dataset.resultIndex = allResults.indexOf(result);
            }
        });
        
        resultContainer.appendChild(fragment);
        
        const openButtons = resultContainer.querySelectorAll('.open-button:not([data-click-handler])');
        openButtons.forEach(button => {
            button.setAttribute('data-click-handler', 'true');
            button._clickHandler = function() {
                openAndWash(this);
            };
            button.addEventListener('click', button._clickHandler);
        });
    }

    if (endIndex >= filteredResults.length) {
        isFullyLoaded = true;
        loadingMore.classList.add('d-none');
        loadingMore.textContent = '已加载全部结果。';
    } else {
        isFullyLoaded = false;
        loadingMore.classList.remove('d-none');
        loadingMore.innerHTML = '<div class="spinner-border spinner-border-sm me-2" role="status"><span class="visually-hidden">Loading...</span></div>加载更多结果...';
    }

    if (currentBatch.length > 0) {
        currentPage++;
    }
    isLoadingNextBatch = false;
    
    updateValidityStatus();
}

/**
 * 更新所有结果的有效性状态
 */
function updateValidityStatus() {
    const resultElements = resultContainer.querySelectorAll('.result-item');
    
    resultElements.forEach(resultElement => {
        const resultIndex = parseInt(resultElement.dataset.resultIndex);
        if (isNaN(resultIndex) || resultIndex < 0 || resultIndex >= allResults.length) {
            return;
        }
        
        const result = allResults[resultIndex];
        const validityBadge = resultElement.querySelector('.validity-badge');
        
        if (result[5] === true || result[5] === false) {
            const validityClass = result[5] ? 'valid-link' : 'invalid-link';
            const validityText = result[5] ? '有效' : '无效';
            
            if (validityBadge) {
                const currentValidityText = validityBadge.textContent.trim();
                if (currentValidityText !== validityText) {
                    validityBadge.className = `validity-badge ${validityClass}`;
                    validityBadge.textContent = validityText;
                }
            } else {
                const resultActions = resultElement.querySelector('.result-actions');
                if (resultActions) {
                    const netdiskBadge = resultActions.querySelector('.netdisk-badge');
                    if (netdiskBadge) {
                        const newValidityBadge = document.createElement('span');
                        newValidityBadge.className = `validity-badge ${validityClass}`;
                        newValidityBadge.textContent = validityText;
                        netdiskBadge.after(newValidityBadge);
                    }
                }
            }
        } else {
            if (validityBadge) {
                validityBadge.remove();
            }
        }
    });
}

// --- 无限滚动逻辑 ---
const infiniteScrollHandler = () => {
    const container = scrollableResultsDiv;
    if ((container.scrollTop + container.clientHeight) >= (container.scrollHeight - 50) && !isSearchRunning && !isFullyLoaded && !isLoadingNextBatch) {
        loadNextPage();
    }
};

function loadNextPage() {
    isLoadingNextBatch = true;
    loadingMore.classList.remove('d-none');

    setTimeout(() => {
        renderResults(false);
    }, 300);
}


/**
 * 检测是否为移动设备
 */
function isMobileDevice() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

/**
 * 打开并洗白链接
 */
function openAndWash(button) {
    const title = button.getAttribute('data-title');
    const url = button.getAttribute('data-url');
    
    // 特殊处理：跳过特定夸克网盘链接的洗白操作
    if (url.includes('pan.quark.cn/s/6176e44c7c0a')) {
        if (isMobileDevice()) {
            window.location.href = url;
        } else {
            const newWindow = window.open(url, '_blank');
            if (!newWindow) {
                showToast('弹出窗口被阻止，请允许弹出窗口后重试', 'warning');
            }
        }
        return;
    }
    
    const originalHtml = button.innerHTML;
    button.disabled = true;
    
    button.classList.remove('btn-outline-primary');
    button.style.border = 'none';
    button.style.outline = 'none';
    button.style.boxShadow = 'none';
    
    button.innerHTML = '';
    
    button.style.width = '65px';
    button.style.height = '15px';
    button.style.padding = '0 10px';
    
    const progressContainer = document.createElement('div');
    progressContainer.className = 'progress-container';
    progressContainer.style.width = '100%';
    progressContainer.style.height = '100%';
    progressContainer.style.backgroundColor = '#e0e0e0';
    progressContainer.style.borderRadius = '8px';
    progressContainer.style.overflow = 'hidden';
    progressContainer.style.boxShadow = 'inset 0 1px 3px rgba(0,0,0,0.2)';
    
    const progressBar = document.createElement('div');
    progressBar.className = 'progress-bar';
    progressBar.style.width = '0%';
    progressBar.style.height = '100%';
    progressBar.style.backgroundColor = '#2196F3';
    progressBar.style.borderRadius = '8px';
    progressBar.style.transition = 'width 0.3s ease';
    progressBar.style.boxShadow = '0 1px 2px rgba(0,0,0,0.2)';
    progressBar.style.backgroundImage = 'linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent)';
    progressBar.style.backgroundSize = '100px 100px';
    
    progressContainer.appendChild(progressBar);
    
    button.appendChild(progressContainer);
    
    let progress = 0;
    const progressInterval = setInterval(() => {
        progress += 10;
        if (progress <= 90) {
            progressBar.style.width = progress + '%';
        }
    }, 300);
    
    fetch('/api/wash', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            share_url: url,
            title: title
        })
    })
    .then(response => response.json())
    .then(data => {
        clearInterval(progressInterval);
        progressBar.style.width = '100%';
        
        setTimeout(() => {
            button.disabled = false;
            button.innerHTML = originalHtml;
            button.style.width = '';
            button.style.height = '';
            button.style.padding = '';
            button.style.border = '';
            button.style.outline = '';
            button.style.boxShadow = '';
            if (!button.classList.contains('btn-outline-primary')) {
                button.classList.add('btn-outline-primary');
            }
            
            if (data.success) {
                const washedUrl = data.data.washed_url;
                
                if (isMobileDevice()) {
                    window.location.href = washedUrl;
                } else {
                    const newWindow = window.open(washedUrl, '_blank');
                    if (!newWindow) {
                        showToast('弹出窗口被阻止，请允许弹出窗口后重试', 'warning');
                    }
                }
            } else {
                showToast('洗白失败: ' + data.message, 'error');
            }
        }, 500);
    })
    .catch(error => {
        clearInterval(progressInterval);
        console.error('洗白请求失败:', error);
        
        progressBar.style.backgroundColor = '#f44336';
        progressBar.style.width = '100%';
        
        setTimeout(() => {
            button.disabled = false;
            button.innerHTML = originalHtml;
            button.style.width = '';
            button.style.height = '';
            button.style.padding = '';
            button.style.border = '';
            button.style.outline = '';
            button.style.boxShadow = '';
            if (!button.classList.contains('btn-outline-primary')) {
                button.classList.add('btn-outline-primary');
            }
            showToast('洗白请求失败，请检查网络', 'error');
        }, 500);
    });
}

/**
 * 单个检查链接的有效性
 */
function checkSingleLinkValidity(result) {
    if (result[5] != null) return;
    
    fetch('/api/check_validity', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ url: result[2] })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            result[5] = data.data.is_valid;
            
            const resultElements = resultContainer.querySelectorAll('.result-item');
            let targetElement = null;
            for (let i = 0; i < resultElements.length; i++) {
                const element = resultElements[i];
                if (element.dataset.resultIndex == allResults.indexOf(result)) {
                    targetElement = element;
                    break;
                }
            }
            
            if (targetElement) {
                let validityBadge = targetElement.querySelector('.validity-badge');
                const validityClass = data.data.is_valid ? 'valid-link' : 'invalid-link';
                const validityText = data.data.is_valid ? '有效' : '无效';
                
                if (validityBadge) {
                    validityBadge.className = `validity-badge ${validityClass}`;
                    validityBadge.textContent = validityText;
                } else {
                    validityBadge = document.createElement('span');
                    validityBadge.className = `validity-badge ${validityClass}`;
                    validityBadge.textContent = validityText;
                    
                    const netdiskBadge = targetElement.querySelector('.netdisk-badge');
                    if (netdiskBadge && netdiskBadge.nextSibling) {
                        targetElement.querySelector('.result-actions').insertBefore(validityBadge, netdiskBadge.nextSibling);
                    } else {
                        targetElement.querySelector('.result-actions').insertBefore(validityBadge, targetElement.querySelector('.open-button'));
                    }
                }
            }
        }
    })
    .catch(error => {
        console.error('检查链接有效性失败:', error);
    });
}

/**
 * 检查用户可见区域的链接有效性
 */
function checkVisibleLinksValidity() {
    const resultElements = resultContainer.querySelectorAll('.result-item');
    
    resultElements.forEach(element => {
        const rect = element.getBoundingClientRect();
        if (rect.top >= 0 && rect.bottom <= window.innerHeight) {
            const index = parseInt(element.dataset.resultIndex);
            if (index >= 0 && index < allResults.length && allResults[index][5] == null) {
                checkSingleLinkValidity(allResults[index]);
            }
        }
    });
}

/**
 * 开始检查所有链接的有效性
 */
function startValidityCheck() {
    if (validityCheckInterval) {
        clearInterval(validityCheckInterval);
    }
    
    setTimeout(() => {
        checkVisibleLinksValidity();
        
        for (let i = 0; i < allResults.length; i++) {
            setTimeout(() => {
                checkSingleLinkValidity(allResults[i]);
            }, i * 100);
        }
    }, 1000);
    
    validityCheckInterval = setInterval(() => {
        const newResults = allResults.filter(result => result[5] == null);
        if (newResults.length > 0) {
            for (let i = 0; i < newResults.length; i++) {
                setTimeout(() => {
                    checkSingleLinkValidity(newResults[i]);
                }, i * 100);
            }
        }
    }, 30000);
    
    window.addEventListener('scroll', () => {
        clearTimeout(window.scrollTimeout);
        window.scrollTimeout = setTimeout(() => {
            checkVisibleLinksValidity();
        }, 200);
    });
}

/**
 * 停止定期检查链接有效性状态
 */
function stopValidityCheck() {
    if (validityCheckInterval) {
        clearInterval(validityCheckInterval);
        validityCheckInterval = null;
    }
}

/**
 * 显示提示消息
 */
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast-message toast-${type}`;
    toast.textContent = message;
    
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 12px 20px;
        border-radius: 6px;
        color: white;
        font-size: 14px;
        z-index: 9999;
        animation: fadeIn 0.3s ease;
        background-color: ${type === 'success' ? '#28a745' : type === 'error' ? '#dc3545' : '#17a2b8'};
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'fadeOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 300);
    }, 3000);
}
