        let apiConfigs = [];

        /**
         * 显示 Toast 通知
         * @param {string} message - 提示消息
         * @param {string} type - 提示类型 ('success', 'danger', 'info', 'warning')
         */


        // 新增：格式化 JSON 输入框内容
        function formatJson(textareaId) {
            const textarea = document.getElementById(textareaId);
            if (!textarea) return;

            try {
                const jsonText = textarea.value.trim();
                if (!jsonText) return;

                // 尝试解析并重新格式化
                const parsedJson = JSON.parse(jsonText);
                textarea.value = JSON.stringify(parsedJson, null, 4);
                showToast('JSON 格式化成功', 'success');
            } catch (e) {
                showToast('JSON 格式化失败: 请检查语法错误', 'danger');
            }
        }

        // 新增：从模态框中获取 API 数据
        function getApiDataFromModal(prefix) {
            const isNewApi = (prefix === 'api');

            // 确保必填字段不为空
            const name = document.getElementById(`${prefix}Name`).value;
            const url = document.getElementById(`${prefix}Url`).value;
            const request = document.getElementById(`${prefix}Request`).value;
            const responseMapping = document.getElementById(`${prefix}Response`).value;

            if (!name || !url || !responseMapping) {
                showToast('请填写所有带 * 的必填字段', 'warning');
                return null;
            }

            // 只有当 request 不为空时才验证 JSON 格式
            if (request && request.trim() !== '') {
                try {
                    JSON.parse(request);
                } catch (e) {
                    showToast('请求体 JSON 格式不正确', 'danger');
                    return null;
                }
            }

            const api = {
                name: name,
                url: url,
                method: document.getElementById(`${prefix}Method`).value,
                request: request,
                response: responseMapping,
                is_enabled: document.getElementById(`${prefix}IsEnabled`).value === 'true',
                id: isNewApi ? 0 : document.getElementById('editApiId').value,
                status: null,
                response_time_ms: null
            };
            return api;
        }

        // 新增：在模态框中测试 API 草稿
        async function testDraftApi(prefix) {
            const testButtonId = (prefix === 'api') ? 'apiTestButton' : 'editApiTestButton';
            const testButton = document.getElementById(testButtonId);
            const originalButtonText = testButton ? testButton.innerHTML : '';
            
            if (testButton) {
                testButton.disabled = true;
                testButton.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> 测试中...';
            }

            const api = getApiDataFromModal(prefix);
            if (!api) {
                if (testButton) {
                    testButton.disabled = false;
                    testButton.innerHTML = originalButtonText;
                }
                return;
            }
            const apiName = api.name;

            try {
                showToast(`正在测试 API: ${apiName}...`, 'info');
                
                const response = await fetch('/api/test', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(api)
                });

                if (!response.ok) {
                    const errorText = await response.text();
                    try {
                        const errorJson = JSON.parse(errorText);
                        throw new Error(errorJson.error || `HTTP错误！状态: ${response.status}`);
                    } catch {
                        throw new Error(`HTTP错误！状态: ${response.status}`);
                    }
                }
                const data = await response.json();

                if (data.status) {
                    showToast(`✅ API ${apiName} 测试成功！耗时 ${data.response_time_ms}ms，配置正确！`, 'success');
                } else {
                    showToast(`⚠️ API ${apiName} 测试失败！请检查配置。可能原因：接口无法访问、响应匹配失败等`, 'danger');
                }

            } catch (error) {
                let errorMessage = error.message;
                if (errorMessage.includes('Failed to fetch')) {
                    errorMessage = '网络连接失败，请检查网络或接口地址';
                }
                showToast(`❌ API ${apiName} 测试失败！${errorMessage}`, 'danger');
            } finally {
                if (testButton) {
                    testButton.disabled = false;
                    testButton.innerHTML = originalButtonText;
                }
            }
        }

        // 从服务器获取 API 配置
        async function loadApiConfigs() {
            try {
                const response = await fetch('/api/configs');
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                apiConfigs = await response.json();
                renderTable();
            } catch (error) {
                console.error('加载 API 配置时出错:', error);
                showToast('加载 API 配置失败，请检查后端连接或日志。', 'danger');
            }
        }

        // 渲染表格
        function renderTable() {
            const tbody = document.getElementById('apiTableBody');
            tbody.innerHTML = '';
            apiConfigs.forEach((api, index) => {
                const statusClass = api.status === true ? 'status-available' : 'status-unavailable';
                const statusText = api.status === true ? '正常' : '异常';
                const timeDisplay = api.response_time_ms !== null && api.response_time_ms > 0 ? `${api.response_time_ms}` : '--';

                let toggleBtnClass;
                let toggleBtnText;
                let toggleBtnIcon;
                let nextAction;
                let isToggleDisabled = '';

                if (api.is_enabled) {
                    toggleBtnClass = 'btn-success';
                    toggleBtnText = '启用';
                    toggleBtnIcon = 'fa-toggle-on';
                    nextAction = false;
                } else {
                    toggleBtnClass = 'btn-danger';
                    toggleBtnText = '禁止';
                    toggleBtnIcon = 'fa-toggle-off';
                    nextAction = true;

                    if (api.status === false) {
                        isToggleDisabled = 'disabled';
                    }
                }

                const rowClass = api.is_enabled ? '' : 'disabled-api';
                const isTestDisabled = '';

                const row = document.createElement('tr');
                row.className = rowClass;
                // 处理请求体和响应体显示
                const requestDisplay = api.request && api.request.trim() ? '<span>已配置</span>' : '<span>无</span>';
                const responseDisplay = api.response && api.response.trim() ? '<i class="fas fa-code"></i>' : '<i class="fas fa-times-circle text-danger"></i>';
                row.innerHTML = `
                    <td>${index + 1}</td>
                    <td><span class="status-button ${statusClass}" title="最新测试结果">${statusText}</span></td>
                    <td>${api.name}</td>
                    <td style="max-width: 400px; overflow: hidden; text-overflow: ellipsis; white-space: normal; word-wrap: break-word;">${api.url}</td>
                    <td>${api.method.toUpperCase()}</td>
                    <td>${timeDisplay}</td>
                    <td>${requestDisplay}</td>
                    <td>${responseDisplay}</td>
                    <td class="action-buttons d-flex justify-content-center align-items-center">
                        <button class="btn btn-sm ${toggleBtnClass}" title="${api.status === false && !api.is_enabled ? 'API异常，请先测试修复后再启用' : '点击切换状态'}"
                                onclick="toggleEnabled(${api.id}, ${nextAction})" ${isToggleDisabled}>
                            <i class="fas ${toggleBtnIcon}"></i> ${toggleBtnText}
                        </button>
                        <button class="btn btn-sm btn-info text-white" onclick="testApi(${api.id})" title="测试单个 API" ${isTestDisabled}>
                            <i class="fas fa-play"></i> 测试
                        </button>
                        <div class="dropdown">
                            <button class="btn btn-sm btn-secondary dropdown-toggle" type="button"
                                data-bs-toggle="dropdown" aria-expanded="false" title="更多操作">
                                <i class="fas fa-ellipsis-v"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li>
                                    <a class="dropdown-item" href="javascript:void(0)" onclick="editApi(${api.id})">
                                        <i class="fas fa-edit me-2"></i> 修改
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="javascript:void(0)" onclick="copyApi(${api.id})">
                                        <i class="fas fa-copy me-2"></i> 复制
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item text-danger" href="javascript:void(0)" onclick="deleteApi(${api.id})">
                                        <i class="fas fa-trash me-2"></i> 删除
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </td>
                `;
                tbody.appendChild(row);
            });
        }

        // 辅助函数：转义HTML字符，防止XSS攻击
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // 辅助函数：根据 ID 查找配置对象和它的当前索引
        function getApiConfigById(apiId) {
            const index = apiConfigs.findIndex(api => api.id == apiId);
            return { api: apiConfigs[index], index: index };
        }

        // 切换单个 API 的启用/禁用状态
        async function toggleEnabled(apiId, isEnabled) {
            const action = isEnabled ? '启用' : '禁止';
            const { api } = getApiConfigById(apiId);

            if (!api) {
                showToast('API 配置不存在!', 'danger');
                return;
            }

            if (isEnabled === true && api.status === false) {
                showToast(`API "${api.name}" 状态异常，无法启用。请先测试并修复。`, 'danger');
                return;
            }

            try {
                const response = await fetch(`/api/configs/${apiId}/enabled`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ is_enabled: isEnabled })
                });

                if (!response.ok) {
                    const errorText = await response.text();
                    try {
                        const errorJson = JSON.parse(errorText);
                        throw new Error(errorJson.message || `HTTP error! status: ${response.status}`);
                    } catch {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                }

                showToast(`API "${api.name}" 已成功${action}。`, 'success');
                loadApiConfigs();
            } catch (error) {
                console.error(`切换 API 启用状态时出错:`, error);
                showToast(`API ${action}失败: ${error.message}`, 'danger');
            }
        }

        // 全部启用所有 API
        async function enableAllApis() {
            const enableAllButton = document.getElementById('enableAllButton');
            if (await showConfirm('确定要【启用】所有 API 配置吗？（状态异常的API将不会被启用）')) {
                enableAllButton.disabled = true;

                try {
                    const response = await fetch('/api/configs/enable-all', { method: 'PUT' });

                    if (!response.ok) {
                        const errorText = await response.text();
                        try {
                            const errorJson = JSON.parse(errorText);
                            throw new Error(errorJson.message || `HTTP error! status: ${response.status}`);
                        } catch {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                    }

                    const data = await response.json();
                    showToast(data.message, 'success');
                    loadApiConfigs();
                } catch (error) {
                    console.error('全部启用 API 时出错:', error);
                    showToast(`全部启用失败: ${error.message}`, 'danger');
                } finally {
                    enableAllButton.disabled = false;
                }
            }
        }

        // 全部禁用 API
        async function disableAllApis() {
            const disableAllButton = document.getElementById('disableAllButton');
            if (await showConfirm('确定要【禁用】所有 API 配置吗？')) {
                disableAllButton.disabled = true;

                try {
                    const response = await fetch('/api/configs/disable-all', { method: 'PUT' });

                    if (!response.ok) {
                        const errorText = await response.text();
                        try {
                            const errorJson = JSON.parse(errorText);
                            throw new Error(errorJson.message || `HTTP error! status: ${response.status}`);
                        } catch {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                    }

                    const data = await response.json();
                    showToast(data.message, 'success');
                    loadApiConfigs();
                } catch (error) {
                    console.error('全部禁用 API 时出错:', error);
                    showToast(`全部禁用失败: ${error.message}`, 'danger');
                } finally {
                    disableAllButton.disabled = false;
                }
            }
        }

        // 添加 API
        async function addApi() {
            const api = getApiDataFromModal('api');
            if (!api) return;

            try {
                const response = await fetch('/api/configs', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(api)
                });

                if (!response.ok) {
                    const errorText = await response.text();
                    try {
                        const errorJson = JSON.parse(errorText);
                        throw new Error(errorJson.message || `HTTP error! status: ${response.status}`);
                    } catch {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                }

                const data = await response.json();
                showToast(data.message, 'success');
                loadApiConfigs();
                document.getElementById('addApiForm').reset();
                bootstrap.Modal.getInstance(document.getElementById('addApiModal')).hide();
            } catch (error) {
                console.error('添加 API 配置时出错:', error);
                showToast(`添加 API 配置失败: ${error.message}`, 'danger');
            }
        }

        // 修改 API
        function editApi(apiId) {
            const { api } = getApiConfigById(apiId);
            if (!api) {
                showToast('未找到该配置！', 'warning');
                return;
            }
            document.getElementById('editApiId').value = apiId;
            document.getElementById('editApiName').value = api.name;
            document.getElementById('editApiUrl').value = api.url;
            document.getElementById('editApiMethod').value = api.method;
            document.getElementById('editApiRequest').value = api.request;
            document.getElementById('editApiResponse').value = api.response;
            document.getElementById('editApiIsEnabled').value = api.is_enabled ? 'true' : 'false';

            new bootstrap.Modal(document.getElementById('editApiModal')).show();
        }

        // 保存修改
        async function saveEditedApi() {
            const apiId = document.getElementById('editApiId').value;
            const isEnabledValue = document.getElementById('editApiIsEnabled').value;

            const { api: originalApi } = getApiConfigById(apiId);
            if (!originalApi) {
                showToast('无法获取原始配置，保存失败！', 'danger');
                return;
            }

            if (isEnabledValue === 'true' && originalApi.status === false) {
                showToast(`API "${originalApi.name}" 状态异常，无法启用。请先测试并修复。`, 'danger');
                return;
            }

            const api = getApiDataFromModal('editApi');
            if (!api) return;

            api.id = apiId;
            api.status = originalApi.status;

            try {
                const response = await fetch(`/api/configs/${apiId}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(api)
                });

                if (!response.ok) {
                    const errorText = await response.text();
                    try {
                        const errorJson = JSON.parse(errorText);
                        throw new Error(errorJson.message || `HTTP error! status: ${response.status}`);
                    } catch {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                }

                const data = await response.json();
                showToast(data.message, 'success');
                loadApiConfigs();
                bootstrap.Modal.getInstance(document.getElementById('editApiModal')).hide();
            } catch (error) {
                console.error('修改 API 配置时出错:', error);
                showToast(`修改 API 配置失败: ${error.message}`, 'danger');
            }
        }

        // 删除 API
        async function deleteApi(apiId) {
            const { api } = getApiConfigById(apiId);
            if (!api) return;

            if (await showConfirm(`确定删除 API "${api.name}" 吗？此操作不可撤销。`, 'danger')) {
                try {
                    const response = await fetch(`/api/configs/${apiId}`, { method: 'DELETE' });

                    if (!response.ok) {
                        const errorText = await response.text();
                        try {
                            const errorJson = JSON.parse(errorText);
                            throw new Error(errorJson.message || `HTTP error! status: ${response.status}`);
                        } catch {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                    }

                    const data = await response.json();
                    showToast(data.message, 'success');
                    loadApiConfigs();
                } catch (error) {
                    console.error('删除 API 配置时出错:', error);
                    showToast(`删除 API 配置失败: ${error.message}`, 'danger');
                }
            }
        }

        // 测试 API (单个)
        async function testApi(apiId) {
            const { api, index } = getApiConfigById(apiId);
            if (!api) return;

            const testButtonSelector = `#apiTableBody tr:nth-child(${index + 1}) .btn-info`;
            const testButton = document.querySelector(testButtonSelector);
            const originalButtonText = testButton ? testButton.innerHTML : '';

            if (testButton) {
                testButton.disabled = true;
                testButton.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> 测试中...';
            }

            try {
                showToast(`正在测试 API: ${api.name}...`, 'info');
                
                const apiWithId = { ...api, id: apiId };
                const response = await fetch('/api/test', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(apiWithId)
                });

                if (!response.ok) {
                    const errorText = await response.text();
                    try {
                        const errorJson = JSON.parse(errorText);
                        throw new Error(errorJson.error || `HTTP错误！状态: ${response.status}`);
                    } catch {
                        throw new Error(`HTTP错误！状态: ${response.status}`);
                    }
                }

                const data = await response.json();
                if (data.status) {
                    showToast(`✅ API ${api.name} 测试成功！耗时 ${data.response_time_ms}ms，状态已更新为正常`, 'success');
                } else {
                    showToast(`⚠️ API ${api.name} 测试失败！状态异常，已自动禁用。可能原因：接口无法访问、响应匹配失败等`, 'warning');
                }

                loadApiConfigs();
            } catch (error) {
                let errorMessage = error.message;
                if (errorMessage.includes('Failed to fetch')) {
                    errorMessage = '网络连接失败，请检查网络或接口地址';
                }
                showToast(`❌ API ${api.name} 测试失败！${errorMessage}`, 'danger');
                loadApiConfigs();
            } finally {
                if (testButton) {
                    testButton.disabled = false;
                    testButton.innerHTML = originalButtonText;
                }
            }
        }

        // 一键测试所有 API
        async function testAllApis() {
            const testAllButton = document.getElementById('testAllButton');
            if (await showConfirm('该操作可能会耗时较久，您确定要测试所有 API 吗？（包括已禁止的）')) {
                testAllButton.disabled = true;

                try {
                    const response = await fetch('/api/test-all');
                    if (!response.ok) {
                        const errorText = await response.text();
                        try {
                            const errorJson = JSON.parse(errorText);
                            throw new Error(errorJson.message || `HTTP error! status: ${response.status}`);
                        } catch {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                    }
                    const data = await response.json();
                    showToast(data.message, 'info');
                    loadApiConfigs();
                } catch (error) {
                    console.error('一键测试所有 API 时出错:', error);
                    showToast(`一键测试所有 API 失败: ${error.message}`, 'danger');
                } finally {
                    testAllButton.disabled = false;
                }
            }
        }

        // 复制 API
        async function copyApi(apiId) {
            // 添加确认提示
            if (await showConfirm('确定要复制此API配置吗？')) {
                try {
                    const response = await fetch(`/api/configs/copy/${apiId}`, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' }
                    });

                    if (!response.ok) {
                        const errorText = await response.text();
                        try {
                            const errorJson = JSON.parse(errorText);
                            throw new Error(errorJson.message || `HTTP error! status: ${response.status}`);
                        } catch {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                    }

                    const data = await response.json();
                    showToast(data.message, 'success');
                    loadApiConfigs();
                } catch (error) {
                    console.error('复制 API 配置时出错:', error);
                    showToast(`复制 API 配置失败: ${error.message}`, 'danger');
                }
            }
        }

        // 初始化加载数据
        loadApiConfigs();

        // ============================================
        // 邮件通知配置功能
        // ============================================

        // 邮箱格式验证
        function isValidEmail(email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        }

        // 显示状态消息
        function showEmailStatus(message, type = 'info') {
            const statusDiv = document.getElementById('emailStatus');
            if (!statusDiv) return;

            let bgColor = '#eff6ff';
            let textColor = '#1e40af';
            let borderColor = '#93c5fd';
            if (type === 'success') {
                bgColor = '#f0fdf4';
                textColor = '#166534';
                borderColor = '#86efac';
            }
            if (type === 'error') {
                bgColor = '#fef2f2';
                textColor = '#991b1b';
                borderColor = '#fca5a5';
            }
            if (type === 'warning') {
                bgColor = '#fffbeb';
                textColor = '#92400e';
                borderColor = '#fcd34d';
            }

            statusDiv.innerHTML = `
                <div style="padding: 12px 16px; background-color: ${bgColor}; color: ${textColor}; border: 1px solid ${borderColor}; border-radius: 4px; position: relative;">
                    ${message}
                    <button type="button" onclick="this.parentElement.remove()" style="position: absolute; top: 8px; right: 8px; background: none; border: none; font-size: 18px; cursor: pointer; color: ${textColor};">&times;</button>
                </div>
            `;

            // 5秒后自动关闭
            setTimeout(() => {
                const alert = statusDiv.querySelector('div');
                if (alert) {
                    alert.remove();
                }
            }, 5000);
        }

        // 加载邮件配置
        function loadEmailConfig() {
            fetch('/api/email/config')
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.config) {
                        const config = data.config;

                        if (config.notification_email) {
                            const el = document.getElementById('emailNotifyTo');
                            if (el) el.value = config.notification_email;
                        }
                        if (config.smtp_server) {
                            const el = document.getElementById('emailSmtpServer');
                            if (el) el.value = config.smtp_server;
                        }
                        if (config.smtp_port) {
                            const el = document.getElementById('emailSmtpPort');
                            if (el) el.value = config.smtp_port;
                        }
                        if (config.smtp_username) {
                            const el = document.getElementById('emailSmtpUser');
                            if (el) el.value = config.smtp_username;
                        }
                        // 密码不回显，显示占位符
                        const passwordEl = document.getElementById('emailSmtpPassword');
                        if (passwordEl) passwordEl.value = '******';
                        if (config.use_tls !== undefined) {
                            const el = document.getElementById('emailUseTls');
                            if (el) el.checked = config.use_tls;
                        }
                        if (config.enabled !== undefined) {
                            const el = document.getElementById('emailNotificationEnabled');
                            if (el) el.checked = config.enabled;
                        }
                    }
                })
                .catch(error => {
                    console.error('加载邮件配置失败:', error);
                });
        }

        // 保存邮件配置
        function saveEmailConfig() {
            const notificationEmailEl = document.getElementById('emailNotifyTo');
            const smtpServerEl = document.getElementById('emailSmtpServer');
            const smtpPortEl = document.getElementById('emailSmtpPort');
            const smtpUsernameEl = document.getElementById('emailSmtpUser');
            const smtpPasswordEl = document.getElementById('emailSmtpPassword');
            const useTlsEl = document.getElementById('emailUseTls');
            const emailEnabledEl = document.getElementById('emailNotificationEnabled');

            const notificationEmail = notificationEmailEl ? notificationEmailEl.value.trim() : '';
            const smtpServer = smtpServerEl ? smtpServerEl.value.trim() : '';
            const smtpPort = smtpPortEl ? (parseInt(smtpPortEl.value) || 587) : 587;
            const smtpUsername = smtpUsernameEl ? smtpUsernameEl.value.trim() : '';
            const smtpPassword = smtpPasswordEl ? smtpPasswordEl.value : '';
            const useTls = useTlsEl ? useTlsEl.checked : true;
            const emailEnabled = emailEnabledEl ? emailEnabledEl.checked : false;

            const config = {
                notification_email: notificationEmail,
                smtp_server: smtpServer,
                smtp_port: smtpPort,
                smtp_username: smtpUsername,
                use_tls: useTls,
                enabled: emailEnabled
            };

            // 只有当密码不是占位符且不为空时，才发送密码
            if (smtpPassword && smtpPassword !== '******') {
                config.smtp_password = smtpPassword;
            }

            // 显示加载状态
            const saveBtn = document.getElementById('saveEmailConfigBtn');
            let originalText = '';
            if (saveBtn) {
                originalText = saveBtn.innerHTML;
                saveBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>保存中...';
                saveBtn.disabled = true;
            }

            fetch('/api/email/config', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(config)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showEmailStatus(data.message, 'success');
                    // 重新设置密码框为占位符
                    if (smtpPasswordEl) smtpPasswordEl.value = '******';
                } else {
                    showEmailStatus(data.message, 'error');
                }
            })
            .catch(error => {
                console.error('保存邮件配置失败:', error);
                showEmailStatus('保存失败: ' + error.message, 'error');
            })
            .finally(() => {
                if (saveBtn) {
                    saveBtn.innerHTML = originalText;
                    saveBtn.disabled = false;
                }
            });
        }

        // 发送测试邮件
        function sendTestEmail() {
            // 显示加载状态
            const testBtn = document.getElementById('testEmailBtn');
            let originalText = '';
            if (testBtn) {
                originalText = testBtn.innerHTML;
                testBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>发送中...';
                testBtn.disabled = true;
            }

            fetch('/api/email/test', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showEmailStatus(data.message, 'success');
                } else {
                    showEmailStatus(data.message, 'error');
                }
            })
            .catch(error => {
                console.error('发送测试邮件失败:', error);
                showEmailStatus('发送失败: ' + error.message, 'error');
            })
            .finally(() => {
                if (testBtn) {
                    testBtn.innerHTML = originalText;
                    testBtn.disabled = false;
                }
            });
        }

        // 绑定邮件配置事件
        function bindEmailConfigEvents() {
            // 邮箱输入验证
            const emailInput = document.getElementById('emailNotifyTo');
            if (emailInput) {
                emailInput.addEventListener('input', function() {
                    if (this.value && !isValidEmail(this.value)) {
                        this.classList.add('is-invalid');
                    } else {
                        this.classList.remove('is-invalid');
                    }
                });
            }
        }

        // 快速配置邮箱
        function quickConfigEmail(type) {
            if (type === 'qq') {
                const smtpServerEl = document.getElementById('emailSmtpServer');
                const smtpPortEl = document.getElementById('emailSmtpPort');
                const useTlsEl = document.getElementById('emailUseTls');
                if (smtpServerEl) smtpServerEl.value = 'smtp.qq.com';
                if (smtpPortEl) smtpPortEl.value = '587';
                if (useTlsEl) useTlsEl.checked = true;
                showToast('已填充QQ邮箱配置，请填写邮箱和授权码', 'info');
            } else if (type === '163') {
                const smtpServerEl = document.getElementById('emailSmtpServer');
                const smtpPortEl = document.getElementById('emailSmtpPort');
                const useTlsEl = document.getElementById('emailUseTls');
                if (smtpServerEl) smtpServerEl.value = 'smtp.163.com';
                if (smtpPortEl) smtpPortEl.value = '465';
                if (useTlsEl) useTlsEl.checked = false;
                showToast('已填充163邮箱配置，请填写邮箱和授权码', 'info');
            } else if (type === 'gmail') {
                const smtpServerEl = document.getElementById('emailSmtpServer');
                const smtpPortEl = document.getElementById('emailSmtpPort');
                const useTlsEl = document.getElementById('emailUseTls');
                if (smtpServerEl) smtpServerEl.value = 'smtp.gmail.com';
                if (smtpPortEl) smtpPortEl.value = '587';
                if (useTlsEl) useTlsEl.checked = true;
                showToast('已填充Gmail配置，请填写邮箱和应用专用密码', 'info');
            }
        }

        // 快速配置QQ邮箱
        function quickConfigQQ() {
            quickConfigEmail('qq');
        }

        // 快速配置163邮箱
        function quickConfig163() {
            quickConfigEmail('163');
        }

        // 快速配置Gmail
        function quickConfigGmail() {
            quickConfigEmail('gmail');
        }

        // 切换邮件配置显示
        function toggleEmailConfig() {
            const section = document.getElementById('emailConfigSection');
            
            if (section) {
                // 直接切换显示/隐藏
                if (section.style.display === 'block') {
                    section.style.display = 'none';
                } else {
                    section.style.display = 'block';
                    loadEmailConfig();
                }
            }
        }

        // 初始化邮件配置
        bindEmailConfigEvents();
        loadEmailConfig();